<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Bredh flat responsive HTML & WHMCS hosting and domains template">
    <meta name="author" content="coodiv.net (nedjai mohamed)">
    <link rel="icon" href="favicon.ico">
    <title>bredh | dedicated hosting</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- main css file -->
    <link href="css/main.min.css" rel="stylesheet">

</head>

<body>
<!-- start body -->

<!-- start modal video -->
<div class="modal fade" id="videomodal" tabindex="-1" role="dialog" aria-labelledby="videomodal" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>

                <!-- 16:9 aspect ratio -->
                <div class="embed-responsive embed-responsive-16by9">
                    <iframe class="embed-responsive-item" id="video"></iframe>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end modal video -->

<div class="preloader">
    <!-- start preloader -->
    <div class="preloader-container">
        <svg version="1.1" id="L5" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px"
             y="0px" viewBox="0 0 100 100" enable-background="new 0 0 0 0" xml:space="preserve">
                <circle fill="#675cda" stroke="none" cx="6" cy="50" r="6">
                    <animateTransform attributeName="transform" dur="1s" type="translate" values="0 15 ; 0 -15; 0 15"
                                      repeatCount="indefinite" begin="0.1"/>
                </circle>
            <circle fill="#675cda" stroke="none" cx="30" cy="50" r="6">
                <animateTransform attributeName="transform" dur="1s" type="translate" values="0 10 ; 0 -10; 0 10"
                                  repeatCount="indefinite" begin="0.2"/>
            </circle>
            <circle fill="#675cda" stroke="none" cx="54" cy="50" r="6">
                <animateTransform attributeName="transform" dur="1s" type="translate" values="0 5 ; 0 -5; 0 5"
                                  repeatCount="indefinite" begin="0.3"/>
            </circle>
            </svg>
        <span>loading</span>
    </div>
</div>
<!-- end preloader -->

<div id="coodiv-header" class="d-flex mx-auto flex-column subpages-header moon-edition">
    <div class="bg_overlay_header">
        <div class="video-bg-nuhost-header">
            <div id="video_cover"></div>
            <video autoplay muted loop>
                <source src="media/coodiv-vid.mp4" type="video/mp4">
            </video>
            <span class="video-bg-nuhost-header-bg"></span>
        </div>

        <div id="particles-bg"></div>
        <div class="bg-img-header-new-moon">&nbsp;</div>
        <span class="header-shapes shape-01"></span>
        <span class="header-shapes shape-02"></span>
        <span class="header-shapes shape-03"></span>
    </div>
    <!-- Fixed navbar -->
    <?php
    include 'navbar.php';
    ?>
    <div class="mt-auto header-top-height"></div>
    <main class="container mb-auto">
        <div class="row">
            <div class="col-md-5 d-flex mx-auto flex-column">
                <div class="mb-auto"></div>
                <h3 class="mt-3 main-header-text-title">Bayİ Hosting
                    <span><br>%100 SSD Disk</span>
                    <span>Plesk Kontrol Panel</span>
                    <span>15 Gün İade Garantisi</span>
                </h3>
            </div>
            <div class="col-md-7">
                <div class="breadcrumb-hosting-pages row">
                    <a class="col-md-2" href="webHosting.php">
                        <img src="img/svgs/hosting.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">web hosting</span>
                    </a>

                    <a class="col-md-2" href="wordpressHosting.php">
                        <img src="img/svgs/servers.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">Wordpress Hosting</span>
                    </a>

                    <a class="col-md-2" href="eCommerceHosting.php">
                        <img src="img/svgs/clouds.svg" alt="#"/>
                        <span class="sub-breadcrumb-host-title">E-Ticaret Hosting</span>
                    </a>

                    <a class="col-md-2" href="mailHosting.php">
                        <img src="img/svgs/dedicated.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">Mail Hosting</span>
                    </a>

                    <a class="col-md-4 active" href="dedicatedHosting.php">
                        <img src="img/svgs/dedicated.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">Bayi Hosting</span>
                    </a>
                </div>
            </div>
        </div>

    </main>
    <div class="mt-auto"></div>
</div>


<section class="padding-100-0-0 position-relative">

    <div class="container-fluid">
        <div class="row justify-content-between">

            <div class="col-md-12 row justify-content-center ">
                <div class="col-md-2">
                    <div class="third-pricing-table ">
                        <div class="plan-header">
                            <span class="headline">Bayi Small</span>

                            <span class="plan-price second-pricing-table-price monthly">
                                <i class="monthly">$78 <span>/mo</span></i>
                                </span>
                            <span class="activated-method">Activate in minutes</span>
                        </div>
                        <div class="package-body">
                            <ul>
                                <li><strong>25 </strong>Web Sitesi</li>
                                <li><strong>40 GB SSD</strong> Disk Alanı</li>
                                <li><strong>1 Core</strong> CPU</li>
                                <li><strong>2048 MB</strong> RAM</li>
                                <li><strong>Sınırsız</strong> Trafik</li>
                                <li><strong>Sınırsız</strong> E-Posta Hesabı</li>
                                <li><strong>Sınırsız</strong> MySQL Veri Tabanı</li>
                                <li><strong>Plesk</strong></li>
                            </ul>
                        </div>
                        <div class="package-footer">
                            <a href="#">order now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="third-pricing-table ">
                        <div class="plan-header">
                            <span class="headline">Bayi Medium</span>

                            <span class="plan-price second-pricing-table-price monthly">
                                <i class="monthly">$78 <span>/mo</span></i>
                                </span>
                            <span class="activated-method">Activate in minutes</span>
                        </div>
                        <div class="package-body">
                            <ul>
                                <li><strong>50 </strong>Web Sitesi</li>
                                <li><strong>60 GB SSD</strong> Disk Alanı</li>
                                <li><strong>1 Core</strong> CPU</li>
                                <li><strong>3072 MB</strong> RAM</li>
                                <li><strong>Sınırsız</strong> Trafik</li>
                                <li><strong>Sınırsız</strong> E-Posta Hesabı</li>
                                <li><strong>Sınırsız</strong> MySQL Veri Tabanı</li>
                                <li><strong>Plesk</strong></li>
                            </ul>
                        </div>
                        <div class="package-footer">
                            <a href="#">order now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="third-pricing-table">
                        <div class="plan-header">
                            <span class="headline">Bayi Large</span>

                            <span class="plan-price second-pricing-table-price monthly">
                                <i class="monthly">$78 <span>/mo</span></i>
                                </span>
                            <span class="activated-method">Activate in minutes</span>
                        </div>
                        <div class="package-body">
                            <ul>
                                <li><strong>100 </strong>Web Sitesi</li>
                                <li><strong>120 GB SSD</strong> Disk Alanı</li>
                                <li><strong>2 Core</strong> CPU</li>
                                <li><strong>4096 MB</strong> RAM</li>
                                <li><strong>Sınırsız</strong> Trafik</li>
                                <li><strong>Sınırsız</strong> E-Posta Hesabı</li>
                                <li><strong>Sınırsız</strong> MySQL Veri Tabanı</li>
                                <li><strong>Plesk</strong></li>
                            </ul>
                        </div>
                        <div class="package-footer">
                            <a href="#">order now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="third-pricing-table ">
                        <div class="plan-header">
                            <span class="headline">Bayi XLarge</span>

                            <span class="plan-price second-pricing-table-price monthly">
                                <i class="monthly">$78 <span>/mo</span></i>
                                </span>
                            <span class="activated-method">Activate in minutes</span>
                        </div>
                        <div class="package-body">
                            <ul>
                                <li><strong>200 </strong>Web Sitesi</li>
                                <li><strong>250 GB SSD</strong> Disk Alanı</li>
                                <li><strong>4 Core</strong> CPU</li>
                                <li><strong>6144 MB</strong> RAM</li>
                                <li><strong>Sınırsız</strong> Trafik</li>
                                <li><strong>Sınırsız</strong> E-Posta Hesabı</li>
                                <li><strong>Sınırsız</strong> MySQL Veri Tabanı</li>
                                <li><strong>Plesk</strong></li>
                            </ul>
                        </div>
                        <div class="package-footer">
                            <a href="#">order now</a>
                        </div>
                    </div>
                </div>


            </div>


        </div>
    </div>
</section>

<section class="section-wth-amwaj">
    <div class="bg_overlay_section-amwaj">
        <img src="img/bg/b_bg_02.jpg" alt="img-bg">
    </div>

    <div class="container">
        <h5 class="title-default-coodiv-tree">High Performance Compute Instances Activate in seconds. Online 24x7<span>Müşterilerinize Profesyonel Bir Hosting Deneyimi Yaşatın!</span>
        </h5>

        <div class="row justify-content-left mr-tp-80">
            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-002-plug"></i>
                    <h5>%100 SSD Disk</h5>
                    <p>%100 SSD disk altyapısı ile web sayfalarındaki hız ve performans
                        artışını hissedin.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-025-router"></i>
                    <h5>Windows Platform</h5>
                    <p>Müşterilerinizin web sitelerini güçlü altyapı ve windows platformda barındırın.</p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-021-virtual-reality"></i>
                    <h5>Müşterinize Özel Panel</h5>
                    <p>Müşterinize kendi hosting’ini kolayca yönetmesi için özel
                        panel sağlayın</p>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <h5 class="title-default-coodiv-tree"><span>İşletmenizi Büyütmek İçin İhtiyacınız Olan Tüm Özellikler</span>
        </h5>

        <div class="row justify-content-left mr-tp-80">
            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-002-plug"></i>
                    <h5>Yönetilebilir</h5>
                    <p>Plesk kontrol paneli ile hosting paketlerinizi dilediğiniz gibi oluşturabilir, kaynak yönetimini
                        kolayca gerçekleştirebilirsiniz.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-025-router"></i>
                    <h5>Esnek</h5>
                    <p>Kurulum aşamasında müşterilerinize tahsis ettiğiniz kaynakları dilediğiniz bir zaman kolaylıkla
                        değiştirebilirsiniz</p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-021-virtual-reality"></i>
                    <h5>Ölçeklenebilir</h5>
                    <p>İşinizi beklenilenden hızlı büyütmeniz durumunda artan kaynak ihtiyaçlarınız için bir üst bayi
                        paketine ücretsiz geçebilirsiniz</p>
                </div>
            </div>
        </div>

    </div>
</section>

<section class="padding-100-0 with-top-border">
    <div class="container">
        <h5 class="title-default-coodiv-two">Sıkça Sorulan Sorular</h5>

        <div class="row justify-content-center mr-tp-40">
            <div class="col-md-9">

                <div class="accordion" id="frequently-questions">

                    <div class="questions-box">
                        <div id="headingOne">
                            <button class="btn questions-title" type="button" data-toggle="collapse"
                                    data-target="#questionone" aria-expanded="true" aria-controls="questionone">
                                Reseller Hosting nedir ?
                            </button>
                        </div>

                        <div id="questionone" class="collapse show questions-reponse" aria-labelledby="headingOne"
                             data-parent="#frequently-questions">
                            Reseller hosting ya da Türkçe ismi ile bayi hosting, kiraladığınız web alanını farklı
                            siteler için kullanmanızı veya kendi müşterilerinize satabilmenizi sağlayan paylaşımlı bir
                            web hosting çeşididir. Size özel sunulan kontrol paneli sayesinde kendi müşterilerinize
                            hosting kaynakları atayabilirsiniz. Kontrol paneli sayesinde alan, bant genişliği, müşteri
                            alan adlarını tanımlama, yetkilendirme işlemlerini ve kolaylıkla yapabilirsiniz.
                        </div>
                    </div>

                    <div class="questions-box">
                        <div id="headingtwo">
                            <button class="btn questions-title collapsed" type="button" data-toggle="collapse"
                                    data-target="#questiontwo" aria-expanded="true" aria-controls="questiontwo">
                                Reseller Hosting kimler için uygundur ?
                            </button>
                        </div>

                        <div id="questiontwo" class="collapse questions-reponse" aria-labelledby="headingtwo"
                             data-parent="#frequently-questions">
                            Bayi hosting paketleri birden fazla alan adı barındırma ihtiyacı olan ve bu alan adları için
                            yönetim panellerine ihtiyaç duyan profesyoneller, müşterileri için geliştirdiği web
                            sitelerini kendi yöneten ya da müşterilerinin yönetimine sunan geliştiriciler, barındırma
                            hizmeti sağlayan uzmanlar, kod geliştiricileri, tasarımcılar ve SEO uzmanları tarafından
                            tercih edilir.
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </div>
</section>


<?php
include 'footer.php';
?>

<!-- jquery -->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<!-- bootstrap JavaScript -->
<script src="js/bootstrap.min.js"></script>
<!-- template JavaScript -->
<script src="js/template-scripts.js"></script>
<!-- flickity JavaScript -->
<script src="js/flickity.pkgd.min.js"></script>
<!-- carousel JavaScript -->
<script src="owlcarousel/owl.carousel.min.js"></script>
<!-- parallax JavaScript -->
<script src="js/parallax.min.js"></script>
<!-- mailchamp JavaScript -->
<script src="js/mailchamp.js"></script>
<!-- bootstrap offcanvas -->
<script src="js/bootstrap.offcanvas.min.js"></script>
<!-- touchSwipe JavaScript -->
<script src="js/jquery.touchSwipe.min.js"></script>

<!-- seconde style additionel JavaScript -->
<script src="js/particles-code.js"></script>
<script src="js/particles.js"></script>
<script src="js/smoothscroll.js"></script>
</body>

</html>