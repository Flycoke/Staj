<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Bredh flat responsive HTML & WHMCS hosting and domains template">
    <meta name="author" content="coodiv.net (nedjai mohamed)">
    <link rel="icon" href="favicon.ico">
    <title>bredh | web hosting</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- main css file -->
    <link href="css/main.min.css" rel="stylesheet">
    <!-- main css file -->
    <link href="css/style.css" rel="stylesheet">

</head>

<body>
<!-- start body -->

<div class="preloader">
    <!-- start preloader -->
    <div class="preloader-container">
        <svg version="1.1" id="L5" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px"
             y="0px" viewBox="0 0 100 100" enable-background="new 0 0 0 0" xml:space="preserve">
                <circle fill="#675cda" stroke="none" cx="6" cy="50" r="6">
                    <animateTransform attributeName="transform" dur="1s" type="translate" values="0 15 ; 0 -15; 0 15"
                                      repeatCount="indefinite" begin="0.1"/>
                </circle>
            <circle fill="#675cda" stroke="none" cx="30" cy="50" r="6">
                <animateTransform attributeName="transform" dur="1s" type="translate" values="0 10 ; 0 -10; 0 10"
                                  repeatCount="indefinite" begin="0.2"/>
            </circle>
            <circle fill="#675cda" stroke="none" cx="54" cy="50" r="6">
                <animateTransform attributeName="transform" dur="1s" type="translate" values="0 5 ; 0 -5; 0 5"
                                  repeatCount="indefinite" begin="0.3"/>
            </circle>
            </svg>
        <span>loading</span>
    </div>
</div>
<!-- end preloader -->

<div id="coodiv-header" class="d-flex mx-auto flex-column subpages-header moon-edition">
    <div class="bg_overlay_header">
        <div class="video-bg-nuhost-header">
            <div id="video_cover"></div>
            <video autoplay muted loop>
                <source src="media/coodiv-vid.mp4" type="video/mp4">
            </video>
            <span class="video-bg-nuhost-header-bg"></span>
        </div>

        <div id="particles-bg"></div>
        <div class="bg-img-header-new-moon">&nbsp;</div>
        <span class="header-shapes shape-01"></span>
        <span class="header-shapes shape-02"></span>
        <span class="header-shapes shape-03"></span>
    </div>
    <!-- Fixed navbar -->
    <?php
    include 'navbar.php';
    ?>
    <div class="mt-auto header-top-height"></div>
    <main class="container mb-auto">
        <div class="row">
            <div class="col-md-5 d-flex mx-auto flex-column">
                <div class="mb-auto"></div>
                <h3 class="mt-3 main-header-text-title">Web Hosting
                    <span><br><strong>Sınırsız</strong> Hosting</span>
                    <span><strong>Sınırsız</strong> SSD Disk Alanı</span>
                    <span><strong>Sınırsız</strong> Trafik</span>
                </h3>
            </div>
            <div class="col-md-7">
                <div class="breadcrumb-hosting-pages row">
                    <a class="col-md-3 active" href="cloudServer.php">
                        <img src="img/svgs/hosting.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">bulut sunucu</span>
                    </a>

                    <a class="col-md-3" href="ecoServer.php">
                        <img src="img/svgs/servers.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">eco sunucu</span>
                    </a>

                    <a class="col-md-3" href="dedicatedServer.php">
                        <img src="img/svgs/clouds.svg" alt="#"/>
                        <span class="sub-breadcrumb-host-title">bayi sunucu</span>
                    </a>

                    <a class="col-md-3" href="xtrremeServer.php">
                        <img src="img/svgs/dedicated.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">Xtreme Sunucu</span>
                    </a>
                </div>
            </div>
        </div>
    </main>
    <div class="mt-auto"></div>
</div>

<section class="padding-100-0-0 position-relative">

    <div class="container-fluid">
        <div class="row justify-content-between">

            <div class="col-md-12 row justify-content-center ">
                <div class="col-md-3">
                    <div class="third-pricing-table ">
                        <div class="plan-header">
                            <span class="headline">Xtreme SAS</span>

                            <span class="plan-price second-pricing-table-price monthly">
                                <i class="monthly">$78 <span>/mo</span></i>
                                </span>
                            <span class="activated-method">Activate in minutes</span>
                        </div>
                        <div class="package-body">
                            <ul>
                                <li><strong>32 GB DDR4</strong> RAM (REG ECC) <br><span class="span-info-servers">Max 768 GB</span>
                                </li>
                                <li><strong>2 x 300</strong> 10K SAS Disk<br><span class="span-info-servers">Max 8 x 2 TB</span>
                                </li>
                                <li><strong>RAID</strong>0 / 1 / 5 / 10<br><span
                                            class="span-info-servers">Hardware</span></li>
                                <li><strong>1 Gbit Bağlantı</strong><br><span
                                            class="span-info-servers">10.000 GB Trafik</span></li>
                            </ul>
                        </div>
                        <div class="package-footer">
                            <a href="#">order now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="third-pricing-table ">
                        <div class="plan-header">
                            <span class="headline">Xtreme SSD </span>

                            <span class="plan-price second-pricing-table-price monthly">
                                <i class="monthly">$78 <span>/mo</span></i>
                                </span>
                            <span class="activated-method">Activate in minutes</span>
                        </div>
                        <div class="package-body">
                            <ul>
                                <li><strong>32 GB DDR4</strong> RAM (REG ECC) <br><span class="span-info-servers">Max 768 GB</span>
                                </li>
                                <li><strong>2 x 240</strong> SSD Disk<br><span
                                            class="span-info-servers">Max 8 x 2 TB</span></li>
                                <li><strong>RAID</strong>0 / 1 / 5 / 10<br><span
                                            class="span-info-servers">Hardware</span></li>
                                <li><strong>1 Gbit Bağlantı</strong><br><span
                                            class="span-info-servers">10.000 GB Trafik</span></li>
                            </ul>
                        </div>
                        <div class="package-footer">
                            <a href="#">order now</a>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
</section>


<section class="section-wth-amwaj">
    <div class="bg_overlay_section-amwaj">
        <img src="img/bg/b_bg_02.jpg" alt="img-bg">
    </div>

    <div class="container">
        <h5 class="title-default-coodiv-tree"><span>Tek Sunucuda Dev Performans</span>
        </h5>

        <div class="row justify-content-left mr-tp-80">
            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-002-plug"></i>
                    <h5>Xeon Silver İşlemci (Çift Soketli)</h5>
                    <p>Yoğun işlem yükleri ve performans ihtiyaçlarınız için sunucunuzu yeni nesil Xeon Silver çift
                        işlemci desteği ile güçlendirin.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-025-router"></i>
                    <h5>Hardware RAID 0/1/5/10 (Max. 16 TB)</h5>
                    <p>RAID desteği ile 8 adet diski aynı anda kullanarak veri yedekliliğinizi yükseltin ve depolama
                        kapasitenizi 16 TB'a çıkartın.</p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-021-virtual-reality"></i>
                    <h5>Enterprise SSD Disk Desteği</h5>
                    <p>I/O kaygısı taşıyan projeleriniz için sunucunuzu %100 SSD alt yapısı ile kurgulayın 4 kata kadar
                        daha yüksek performansa sahip olun.</p>
                </div>
            </div>
        </div>

        <div class="row justify-content-left mr-tp-30">
            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-032-sata"></i>
                    <h5>Geliştirilmiş Donanım Performansı</h5>
                    <p>Intel Hyber-Threading ve Intel Turbo Boost 2.0 tekknolojisi desteği ile yoğun sorgu yükü altında
                        bile güçlü performans alın.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-037-cable"></i>
                    <h5>1536 GB RAM Desteği (MAX. 24 X 64 GB)</h5>
                    <p>RAID desteği ile 8 adet diski aynı anda kullanarak veri yedekliliğinizi yükseltin ve depolama
                        kapasitenizi 16 TB'a çıkartın.</p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-045-car-key"></i>
                    <h5>Intel Run Sure Güvenlik Teknolojisi</h5>
                    <p>En kritik iş yükleri için ileri düzey RAS ve sürücü çalışma süresi sunan geliştirilmiş Intel Run
                        Sure Teknolojisi ile tanışın.</p>
                </div>
            </div>
        </div>

    </div>
</section>

<section class="padding-100-0 with-top-border">
    <div class="container">
        <h5 class="title-default-coodiv-two">Sıkça Sorulan Sorular</h5>

        <div class="row justify-content-center mr-tp-40">
            <div class="col-md-9">

                <div class="accordion" id="frequently-questions">

                    <div class="questions-box">
                        <div id="headingOne">
                            <button class="btn questions-title" type="button" data-toggle="collapse"
                                    data-target="#questionone" aria-expanded="true" aria-controls="questionone">
                                Xtreme Sunucu nedir ?
                            </button>
                        </div>

                        <div id="questionone" class="collapse show questions-reponse" aria-labelledby="headingOne"
                             data-parent="#frequently-questions">
                            Daha fazla kaynak gerektiren özel projeleriniz için, yüksek spesifikasyonlara sahip
                            donanımsal ve yazılımsal yapılandırma seçenekleri sunan, esnek bir fiziksel sunucu kiralama
                            çözümüdür.
                        </div>
                    </div>

                    <div class="questions-box">
                        <div id="headingtwo">
                            <button class="btn questions-title collapsed" type="button" data-toggle="collapse"
                                    data-target="#questiontwo" aria-expanded="true" aria-controls="questiontwo">
                                Xtreme Sunucu kimler içindir ?
                            </button>
                        </div>

                        <div id="questiontwo" class="collapse questions-reponse" aria-labelledby="headingtwo"
                             data-parent="#frequently-questions">
                            Yüksek kaynak ihtiyacı olan ve sunucu kaynağını paylaşımsız olarak kullanmak isteyen
                            kullanıcılar için idealdir. Xtreme Server’ı tercih eden kullanıcılar, bu yüksek kaynağı
                            yönetecek donanımsal özellikleri, donanım kapasiteleri dâhilinde dilediği gibi
                            belirleyebilirler.
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </div>
</section>


<?php
include 'footer.php';
?>

<!-- jquery -->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<!-- bootstrap JavaScript -->
<script src="js/bootstrap.min.js"></script>
<!-- template JavaScript -->
<script src="js/template-scripts.js"></script>
<!-- flickity JavaScript -->
<script src="js/flickity.pkgd.min.js"></script>
<!-- carousel JavaScript -->
<script src="owlcarousel/owl.carousel.min.js"></script>
<!-- parallax JavaScript -->
<script src="js/parallax.min.js"></script>
<!-- mailchamp JavaScript -->
<script src="js/mailchamp.js"></script>
<!-- bootstrap offcanvas -->
<script src="js/bootstrap.offcanvas.min.js"></script>
<!-- touchSwipe JavaScript -->
<script src="js/jquery.touchSwipe.min.js"></script>

<!-- seconde style additionel JavaScript -->
<script src="js/particles-code.js"></script>
<script src="js/particles.js"></script>
<script src="js/smoothscroll.js"></script>
</body>

</html>