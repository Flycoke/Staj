<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Bredh flat responsive HTML & WHMCS hosting and domains template">
    <meta name="author" content="coodiv.net (nedjai mohamed)">
    <link rel="icon" href="favicon.ico">
    <title>bredh | cloud VPS</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- main css file -->
    <link href="css/main.min.css" rel="stylesheet">
    <!-- main css file -->
    <link href="css/style.css" rel="stylesheet">

</head>

<body>
<!-- start body -->

<!-- start modal video -->
<div class="modal fade" id="videomodal" tabindex="-1" role="dialog" aria-labelledby="videomodal" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>

                <!-- 16:9 aspect ratio -->
                <div class="embed-responsive embed-responsive-16by9">
                    <iframe class="embed-responsive-item" id="video"></iframe>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end modal video -->

<div class="preloader">
    <!-- start preloader -->
    <div class="preloader-container">
        <svg version="1.1" id="L5" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px"
             y="0px" viewBox="0 0 100 100" enable-background="new 0 0 0 0" xml:space="preserve">
                <circle fill="#675cda" stroke="none" cx="6" cy="50" r="6">
                    <animateTransform attributeName="transform" dur="1s" type="translate" values="0 15 ; 0 -15; 0 15"
                                      repeatCount="indefinite" begin="0.1"/>
                </circle>
            <circle fill="#675cda" stroke="none" cx="30" cy="50" r="6">
                <animateTransform attributeName="transform" dur="1s" type="translate" values="0 10 ; 0 -10; 0 10"
                                  repeatCount="indefinite" begin="0.2"/>
            </circle>
            <circle fill="#675cda" stroke="none" cx="54" cy="50" r="6">
                <animateTransform attributeName="transform" dur="1s" type="translate" values="0 5 ; 0 -5; 0 5"
                                  repeatCount="indefinite" begin="0.3"/>
            </circle>
            </svg>
        <span>loading</span>
    </div>
</div>
<!-- end preloader -->

<div id="coodiv-header" class="d-flex mx-auto flex-column subpages-header moon-edition">
    <div class="bg_overlay_header">
        <div class="video-bg-nuhost-header">
            <div id="video_cover"></div>
            <video autoplay muted loop>
                <source src="media/coodiv-vid.mp4" type="video/mp4">
            </video>
            <span class="video-bg-nuhost-header-bg"></span>
        </div>

        <div id="particles-bg"></div>
        <div class="bg-img-header-new-moon">&nbsp;</div>
        <span class="header-shapes shape-01"></span>
        <span class="header-shapes shape-02"></span>
        <span class="header-shapes shape-03"></span>
    </div>

    <!-- Fixed navbar -->
    <?php
    include 'navbar.php';
    ?>
    <div class="mt-auto header-top-height"></div>
    <main class="container mb-auto">
        <div class="row">
            <div class="col-md-5 d-flex mx-auto flex-column">
                <div class="mb-auto"></div>
                <h3 class="mt-3 main-header-text-title">E-Ticaret Hosting
                    <span><br><strong>iyzico - Hazır Sanal POS </strong>(Tüm Bankalar)</span>
                    <span><strong>Hazır Tema </strong>Seçenekleri</span>
                    <span><strong>Ömürboyu Ücretsiz </strong>Comodo SSL</span>
                </h3>
            </div>
            <div class="col-md-7">
                <div class="breadcrumb-hosting-pages row">
                    <a class="col-md-2" href="webHosting.php">
                        <img src="img/svgs/hosting.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">web hosting</span>
                    </a>

                    <a class="col-md-2" href="wordpressHosting.php">
                        <img src="img/svgs/servers.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">Wordpress Hosting</span>
                    </a>

                    <a class="col-md-4 active" href="eCommerceHosting.php">
                        <img src="img/svgs/clouds.svg" alt="#"/>
                        <span class="sub-breadcrumb-host-title">E-Ticaret Hosting</span>
                    </a>

                    <a class="col-md-2" href="mailHosting.php">
                        <img src="img/svgs/dedicated.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">Mail Hosting</span>
                    </a>
                    <a class="col-md-2" href="dedicatedHosting.php">
                        <img src="img/svgs/dedicated.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">Bayi Hosting</span>
                    </a>
                </div>
            </div>
        </div>

    </main>
    <div class="mt-auto"></div>
</div>

<section class="padding-100-0-0 position-relative">

    <div class="container-fluid">
        <div class="row justify-content-between">

            <div class="col-md-12 row justify-content-center">
                <div class="col-md-2">
                    <div class="third-pricing-table ">
                        <div class="plan-header">
                            <span class="headline">E-Başlangıç</span>

                            <span class="plan-price second-pricing-table-price monthly">
                                <i class="monthly">$78 <span>/mo</span></i>
                                </span>
                            <span class="activated-method">Activate in minutes</span>
                        </div>
                        <div class="package-body">
                            <ul>
                                <li><strong>Hazır </strong>Sanal POS (iyzico)</li>
                                <li><strong>10 GB SSD</strong> Disk Alanı</li>
                                <li><strong>Sınırsız</strong> Trafik</li>
                                <li><strong>2 Core</strong> CPU</li>
                                <li><strong>1024 MB</strong> RAM</li>
                                <li><strong>Comodo Positive</strong> SSL</li>
                                <li><strong>Günlük</strong> Yedekleme</li>
                                <li><strong>50 Adet</strong> Standart E-Posta</li>
                                <li class="lineThrough"><strong>Mail Pro</strong> </li>
                                <li><strong>MySQL</strong> Veritabanı</li>
                                <li><strong>Ücretsiz</strong> Alan Adı</li>
                            </ul>
                        </div>
                        <div class="package-footer">
                            <a href="#">order now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="third-pricing-table ">
                        <div class="plan-header">
                            <span class="headline">E-Girişimci</span>

                            <span class="plan-price second-pricing-table-price monthly">
                                <i class="monthly">$78 <span>/mo</span></i>
                                </span>
                            <span class="activated-method">Activate in minutes</span>
                        </div>
                        <div class="package-body">
                            <ul>
                                <li><strong>Hazır </strong>Sanal POS (iyzico)</li>
                                <li><strong>30 GB SSD</strong> Disk Alanı</li>
                                <li><strong>Sınırsız</strong> Trafik</li>
                                <li><strong>3 Core</strong> CPU</li>
                                <li><strong>1024 MB</strong> RAM</li>
                                <li><strong>Comodo Positive</strong> SSL</li>
                                <li><strong>Günlük</strong> Yedekleme</li>
                                <li><strong>Sınırsız</strong> Standart E-Posta</li>
                                <li class="lineThrough"><strong>Mail Pro</strong> </li>
                                <li><strong>MySQL</strong> Veritabanı</li>
                                <li><strong>Ücretsiz</strong> Alan Adı</li>
                            </ul>
                        </div>
                        <div class="package-footer">
                            <a href="#">order now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="third-pricing-table">
                        <div class="plan-header">
                            <span class="headline">E-Uzman</span>

                            <span class="plan-price second-pricing-table-price monthly">
                                <i class="monthly">$78 <span>/mo</span></i>
                                </span>
                            <span class="activated-method">Activate in minutes</span>
                        </div>
                        <div class="package-body">
                            <ul>
                                <li><strong>Hazır </strong>Sanal POS (iyzico)</li>
                                <li><strong>100 GB SSD</strong> Disk Alanı</li>
                                <li><strong>Sınırsız</strong> Trafik</li>
                                <li><strong>4 Core</strong> CPU</li>
                                <li><strong>2048 MB</strong> RAM</li>
                                <li><strong>Comodo Positive</strong> SSL</li>
                                <li><strong>Günlük</strong> Yedekleme</li>
                                <li><strong>Sınırsız</strong> Standart E-Posta</li>
                                <li><strong>5 Adet</strong> Mail Pro(10 GB)</li>
                                <li><strong>MySQL</strong> Veritabanı</li>
                                <li><strong>Ücretsiz</strong> Alan Adı</li>
                            </ul>
                        </div>
                        <div class="package-footer">
                            <a href="#">order now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="third-pricing-table ">
                        <div class="plan-header">
                            <span class="headline">E-Profesyonel</span>

                            <span class="plan-price second-pricing-table-price monthly">
                                <i class="monthly">$78 <span>/mo</span></i>
                                </span>
                            <span class="activated-method">Activate in minutes</span>
                        </div>
                        <div class="package-body">
                            <ul>
                                <li><strong>Hazır </strong>Sanal POS (iyzico)</li>
                                <li><strong>Sınırsız SSD</strong> Disk Alanı</li>
                                <li><strong>Sınırsız</strong> Trafik</li>
                                <li><strong>6 Core</strong> CPU</li>
                                <li><strong>4096 MB</strong> RAM</li>
                                <li><strong>Comodo Positive</strong> SSL</li>
                                <li><strong>Günlük</strong> Yedekleme</li>
                                <li><strong>Sınırsız</strong> Standart E-Posta</li>
                                <li><strong>25 Adet</strong> Mail Pro(10 GB)</li>
                                <li><strong>MySQL</strong> Veritabanı</li>
                                <li><strong>Ücretsiz</strong> Alan Adı</li>
                            </ul>
                        </div>
                        <div class="package-footer">
                            <a href="#">order now</a>
                        </div>
                    </div>
                </div>


            </div>


        </div>
    </div>
</section>

<section class="section-wth-amwaj">
    <div class="bg_overlay_section-amwaj">
        <img src="img/bg/b_bg_02.jpg" alt="img-bg">
    </div>

    <div class="container">
        <h5 class="title-default-coodiv-tree">High Performance Compute Instances Activate in seconds. Online 24x7<span>En Pratik ve En Ekonomik E-Ticaret Çözümü</span>
        </h5>

        <div class="row justify-content-left mr-tp-80">
            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-002-plug"></i>
                    <h5>Hazır Sanal Pos Kurulumu</h5>
                    <p>E-Ticaret paketinizle kurulu gelen iyzico Sanal Pos ile tüm kredi kartlarından ister peşin ister
                        taksitle ödeme alın!</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-025-router"></i>
                    <h5>Ücretsiz E-Ticaret Temaları</h5>
                    <p>Wordpress - WooCommerce altyapısı ile çalışan e-ticaret sitenize hazır gelen ücretsiz temalardan
                        dilediğinizi seçin ve kullanın!</p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-021-virtual-reality"></i>
                    <h5>Ömürboyu Ücretsiz Comodo SSL</h5>
                    <p>E-Ticaret paketinizin aktif olduğu süre boyunca Comodo Positive SSL ücretsiz olarak yenilensin.
                        Müşteri verileriniz daima güvende kalsın!</p>
                </div>
            </div>
        </div>

    </div>
</section>

<section class="padding-100-0-0 with-top-border">
    <div class="container">
        <h5 class="title-default-coodiv-two">Sıkça Sorulan Sorular</h5>

        <div class="row justify-content-center mr-tp-40">
            <div class="col-md-9">

                <div class="accordion" id="frequently-questions">

                    <div class="questions-box">
                        <div id="headingOne">
                            <button class="btn questions-title" type="button" data-toggle="collapse"
                                    data-target="#questionone" aria-expanded="true" aria-controls="questionone">
                                E-Ticaret Hosting Nedir ?
                            </button>
                        </div>

                        <div id="questionone" class="collapse show questions-reponse" aria-labelledby="headingOne"
                             data-parent="#frequently-questions">
                            E-Ticaret, ürün ya da hizmetlerinizi siteniz üzerinden (online mağaza olarak da bilinir)
                            müşterilerinize sunabileceğiniz ve sipariş alabileceğiniz yöntemdir. <br><br>

                            Natro E-Ticaret Hosting paketleri ile mobil uyumlu, sınırsız sayıda ürün eklenebilen,
                            kolayca müşteri paneli üzerinden yönetilebilen online mağazanızı hemen oluşturabilirsiniz.
                            Natro E-Ticaret Hosting paketlerinde, dünyada en çok tercih edilen e-ticaret altyapısı olan
                            WordPress – WooCommerce kullanılmıştır. Ayrıca paket içinde hazır kurulu gelecek Türkiye’nin
                            en büyük ödeme sistemlerinden iyzico entegrasyonu ile, tüm bankalardan hemen ödeme almaya
                            başlayabilirsiniz.
                        </div>
                    </div>

                    <div class="questions-box">
                        <div id="headingtwo">
                            <button class="btn questions-title collapsed" type="button" data-toggle="collapse"
                                    data-target="#questiontwo" aria-expanded="true" aria-controls="questiontwo">
                                iyzico Sanal POS(iyziPOS) Nedir ?
                            </button>
                        </div>

                        <div id="questiontwo" class="collapse questions-reponse" aria-labelledby="headingtwo"
                             data-parent="#frequently-questions">
                            iyzico, 2013 yılında kurulan, 300 binin üzerinde üye iş yerine ödeme sistemleri alanında
                            hizmet sağlayan, tüketiciler için geliştirdiği ürünlerle online alışveriş dünyasında hızlı
                            ve güvenli bir alışveriş deneyimi sunan BDDK lisanslı bir teknoloji şirketidir. Sanal POS
                            çözümü olan iyziPOS ile e-ticaret siteleri ister peşin ister taksitle ödeme almaya
                            başlayabileceği gibi aynı zamanda yabancı para birimleri ve alternatif ödeme yöntemleriyle
                            de satış yapabilir. Detaylı bilgi için www.iyzico.com/iyzipos sayfasını ziyaret
                            edebilirsiniz.
                        </div>
                    </div>

                    <div class="questions-box">
                        <div id="headingtree">
                            <button class="btn questions-title collapsed" type="button" data-toggle="collapse"
                                    data-target="#questiontree" aria-expanded="true" aria-controls="questiontree">
                                iyzico Sanal POS Aktivasyonu Nasıl Yapılır?
                            </button>
                        </div>

                        <div id="questiontree" class="collapse questions-reponse" aria-labelledby="headingtree"
                             data-parent="#frequently-questions">
                            Sanal POS aktivasyonu için web sitesi üzerinde aktif edilmiş SSL sertifikası, Mesafeli Satış
                            Sözleşmesi, Teslimat ve İade şartları, Gizlilik Politikası, Hakkımızda ve İletişim
                            sayfaları, Visa ve Mastercard logoları bulunması zorunludur. SSL sertifikası E-Ticaret
                            Hosting paketleri için Natro tarafından otomatik olarak aktif edilir, Visa ve Mastercard
                            logoları web sitelerinin en alt kısmına otomatik olarak yerleştirilir. Bunların haricinde
                            gerekli olan tüm sayfaların ve sözleşmelerin taslakları da otomatik olarak web sitesi ile
                            yüklü gelmektedir. <br> <br>

                            Ödemelerinizi almaya başlamak için tek yapmanız gereken, “sözleşme ve politikalar”
                            içeriklerinde yer alan size özel firma bilgilerini düzenlemektir. Bu şartlar ve iyzico
                            tarafından istenilen vergi levhası, imza sirküsü gibi bilgiler karşılandığında, yaptığınız
                            satışlara karşılık gelen ödemeleriniz düzenli olarak hesabınıza aktarılacaktır. İstenen
                            evrakların tamamlanması için iyzico ile iletişime geçilmelidir
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </div>
</section>



<?php
include 'footer.php';
?>

<!-- jquery -->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<!-- bootstrap JavaScript -->
<script src="js/bootstrap.min.js"></script>
<!-- template JavaScript -->
<script src="js/template-scripts.js"></script>
<!-- flickity JavaScript -->
<script src="js/flickity.pkgd.min.js"></script>
<!-- carousel JavaScript -->
<script src="owlcarousel/owl.carousel.min.js"></script>
<!-- parallax JavaScript -->
<script src="js/parallax.min.js"></script>
<!-- mailchamp JavaScript -->
<script src="js/mailchamp.js"></script>
<!-- bootstrap offcanvas -->
<script src="js/bootstrap.offcanvas.min.js"></script>
<!-- touchSwipe JavaScript -->
<script src="js/jquery.touchSwipe.min.js"></script>
<!-- seconde style additionel JavaScript -->
<script src="js/particles-code.js"></script>
<script src="js/particles.js"></script>
<script src="js/smoothscroll.js"></script>
</body>

</html>