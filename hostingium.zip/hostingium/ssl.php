<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Bredh flat responsive HTML & WHMCS hosting and domains template">
    <meta name="author" content="coodiv.net (nedjai mohamed)">
    <link rel="icon" href="favicon.ico">
    <title>bredh | SSL Certificate</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- main css file -->
    <link href="css/main.min.css" rel="stylesheet">

</head>

<body>
<!-- start body -->

<!-- start modal video -->
<div class="modal fade" id="videomodal" tabindex="-1" role="dialog" aria-labelledby="videomodal" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>

                <!-- 16:9 aspect ratio -->
                <div class="embed-responsive embed-responsive-16by9">
                    <iframe class="embed-responsive-item" id="video"></iframe>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end modal video -->

<div class="preloader">
    <!-- start preloader -->
    <div class="preloader-container">
        <svg version="1.1" id="L5" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px"
             y="0px" viewBox="0 0 100 100" enable-background="new 0 0 0 0" xml:space="preserve">
                <circle fill="#675cda" stroke="none" cx="6" cy="50" r="6">
                    <animateTransform attributeName="transform" dur="1s" type="translate" values="0 15 ; 0 -15; 0 15"
                                      repeatCount="indefinite" begin="0.1"/>
                </circle>
            <circle fill="#675cda" stroke="none" cx="30" cy="50" r="6">
                <animateTransform attributeName="transform" dur="1s" type="translate" values="0 10 ; 0 -10; 0 10"
                                  repeatCount="indefinite" begin="0.2"/>
            </circle>
            <circle fill="#675cda" stroke="none" cx="54" cy="50" r="6">
                <animateTransform attributeName="transform" dur="1s" type="translate" values="0 5 ; 0 -5; 0 5"
                                  repeatCount="indefinite" begin="0.3"/>
            </circle>
            </svg>
        <span>loading</span>
    </div>
</div>
<!-- end preloader -->

<div id="coodiv-header" class="d-flex mx-auto flex-column subpages-header  moon-edition">
    <div class="bg_overlay_header">
        <div class="video-bg-nuhost-header">
            <div id="video_cover"></div>
            <video autoplay muted loop>
                <source src="media/coodiv-vid.mp4" type="video/mp4">
            </video>
            <span class="video-bg-nuhost-header-bg"></span>
        </div>

        <div id="particles-bg"></div>
        <div class="bg-img-header-new-moon">&nbsp;</div>
        <span class="header-shapes shape-01"></span>
        <span class="header-shapes shape-02"></span>
        <span class="header-shapes shape-03"></span>
    </div>
    <!-- Fixed navbar -->
    <?php
    include 'navbar.php';
    ?>
    <div class="mt-auto header-top-height"></div>
    <main class="container mb-auto">
        <h3 class="mt-3 main-header-text-title">
            <span>SSL ile web sitenizi güvenli hale getirin ve müşterilerinizin güvenini kazanın </span>SSL Sertifikası
        </h3>

    </main>
    <div class="mt-auto"></div>
</div>


<section>
    <div class="container">
        <div class="row justify-content-start">

            <div class="col-md-3 plan-ssl-special">
                <h5 class="res-titl">hızlı kurulum SSL <span>Anında Kurulum, Belge Gerektirmez</span></h5>
                <span class="res-price">86,84<i>₺</i></span>
                <span class="res-sub-text">Basit Şifreleme  <img src="img/demo/ssl.png" alt=""/></span>

                <div class="body-ress-v2">
                    <p><b>ÜCRETSİZ</b> Alan Adı Dahil</p>
                    <p><b>Günlük Yedeklemeler</b></p>
                    <p>Ücretsiz <b>CDN & Web sitesi</b> Oluşturucu</p>
                    <p><s>Sınırsız <b>Premium SSL</s></b></p>
                    <p><s><b>DDOS</b> Koruması</s></p>
                    <p><a class="ress-install-btn" href="#">Satın Al</a></p>
                </div>
            </div>
            <div class="col-md-3 plan-ssl-special">
                <h5 class="res-titl">ŞİRKETLER İÇİN SSL<span>Kurumsal Doğrulama, Yüksek Güvenlik</span></h5>
                <span class="res-price">434,55<i>₺</i></span>
                <span class="res-sub-text">Basit Şifreleme  <img src="img/demo/ssl.png" alt=""/></span>

                <div class="body-ress-v2">
                    <p><b>ÜCRETSİZ</b> Alan Adı Dahil</p>
                    <p><b>Günlük Yedeklemeler</b></p>
                    <p>Ücretsiz <b>CDN & Web sitesi</b> Oluşturucu</p>
                    <p><s>Sınırsız <b>Premium SSL</s></b></p>
                    <p><s><b>DDOS</b> Koruması</s></p>
                    <p><a class="ress-install-btn" href="#">Satın Al</a></p>
                </div>
            </div>

            <div class="col-md-3 plan-ssl-special">
                <h5 class="res-titl">WILDCARD SSL<span>Alan Adı ve Subdomainleri Kapsayan Tam Koruma</span></h5>
                <span class="res-price">921,44<i>₺</i></span>
                <span class="res-sub-text">İleri Düzey Şifreleme  <img src="img/demo/ssl.png" alt=""/></span>

                <div class="body-ress-v2">
                    <p><b>ÜCRETSİZ</b> Alan Adı Dahil</p>
                    <p><b>Günlük Yedeklemeler</b></p>
                    <p>Ücretsiz <b>CDN & Web sitesi</b> Oluşturucu</p>
                    <p>Sınırsız <b>Premium SSL</b></p>
                    <p><s><b>DDOS</b> Koruması</s></p>
                    <p><a class="ress-install-btn" href="#">Satın Al</a></p>
                </div>
            </div>

            <div class="col-md-3 plan-ssl-special">
                <h5 class="res-titl">KURUMSAL SSL <span>Yeşil Adres Çubuğu (Greenbar) ile Güven Verir</span></h5>
                <span class="res-price">1.477,69<i>₺</i></span>
                <span class="res-sub-text">En İyi Şifreleme <img src="img/demo/ssls.png" alt=""/></span>

                <div class="body-ress-v2">
                    <p><b>ÜCRETSİZ</b> Alan Adı Dahil</p>
                    <p><b>Günlük Yedeklemeler</b></p>
                    <p>Ücretsiz <b>CDN & Web sitesi</b> Oluşturucu</p>
                    <p>Sınırsız <b>Premium SSL</b></p>
                    <p><b>DDOS</b> Koruması</p>
                    <p><a class="ress-install-btn" href="#">Satın Al</a></p>
                </div>
            </div>


        </div>
    </div>
</section>

<section class="section-wth-amwaj">
    <div class="bg_overlay_section-amwaj">
        <img src="img/bg/b_bg_02.jpg" alt="img-bg">
    </div>

    <div class="container">
        <h5 class="title-default-coodiv-tree"><span>SSL Sertifikası İle Güvendesiniz</span>
        </h5>

        <div class="row justify-content-left mr-tp-80">
            <div class="col-md-6">
                <div class="features-box-style-two">
                    <i class="e-flaticon-002-plug"></i>
                    <h5>Google‘da Yükselin</h5>
                    <p>Google, SSL Sertifikası sahibi HTTPS url yapısında web sitelerini arama sonuçlarında
                        önceliklendirir ve daha üst sıralarda listeler.</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="features-box-style-two">
                    <i class="e-flaticon-025-router"></i>
                    <h5>Güçlü Şifreleme</h5>
                    <p>Web sitenizin veri trafiği güçlü şifreleme ile güven altına alınır. Üyelik ve kredi kartı
                        bilgisi, gibi hassas bilgilerin ele geçirilmesi engellenir.</p>
                </div>
            </div>
        </div>
        <div class="row justify-content-left mr-tp-30">
            <div class="col-md-6">
                <div class="features-box-style-two">
                    <i class="e-flaticon-021-virtual-reality"></i>
                    <h5>Hızlı Kurulum</h5>
                    <p>Kurulum için uzun bekleme süreleri ile vakit kaybetmeden, Natro’da barındırılan web siteleri için
                        otomatik kurulum yapılır.</p>
                </div>
            </div>


            <div class="col-md-6">
                <div class="features-box-style-two">
                    <i class="e-flaticon-032-sata"></i>
                    <h5>Tüm Bankalarla Uyumlu</h5>
                    <p>Natro’da satışı olan SSL sertifikaları, sanal pos hizmeti veren tüm bankalar ve ödeme sistemleri
                        ile tam uyumludur.</p>
                </div>
            </div>
        </div>
</section>


<section class="padding-100-0 with-top-border">
    <div class="container">
        <h5 class="title-default-coodiv-two">Sıkça Sorulan Sorular</h5>

        <div class="row justify-content-center mr-tp-40">
            <div class="col-md-9">

                <div class="accordion" id="frequently-questions">

                    <div class="questions-box">
                        <div id="headingOne">
                            <button class="btn questions-title" type="button" data-toggle="collapse"
                                    data-target="#questionone" aria-expanded="true" aria-controls="questionone">
                                SSL nedir?
                            </button>
                        </div>

                        <div id="questionone" class="collapse show questions-reponse" aria-labelledby="headingOne"
                             data-parent="#frequently-questions">
                            SSL Sertifikası iki nokta arasındaki veri iletişiminin şifrelenmiş olarak güvenli bir
                            şekilde yapılmasını sağlayan ve site adreslerinin doğruluğunu kontrol eden bir üründür.
                            Özellikle e-ticaret platformlarında güvenli ödeme işlemlerinin gerçekleştirilmesini
                            sağlayarak, kredi kartı ve kişisel verilerin şifrelelenerek iletilmesine olanak tanır.
                        </div>
                    </div>

                    <div class="questions-box">
                        <div id="headingtwo">
                            <button class="btn questions-title collapsed" type="button" data-toggle="collapse"
                                    data-target="#questiontwo" aria-expanded="true" aria-controls="questiontwo">
                                SSL Sertifikası Nasıl Alınır?
                            </button>
                        </div>

                        <div id="questiontwo" class="collapse questions-reponse" aria-labelledby="headingtwo"
                             data-parent="#frequently-questions">
                            SSL Sertifikasının sipariş işlemi tek aşamada gerçekleştirilmektedir. Satın almak
                            istediğiniz sertifikayı sepetinize ekleyerek ödeme yapmanız sonrası, Müşteri Paneliniz
                            üzerinde ilgili menü üzerinden CSR Kodu üreterek SSL Sertifikası kurulumunu
                            gerçekleştirebilirsiniz.
                        </div>
                    </div>

                    <div class="questions-box">
                        <div id="headingtree">
                            <button class="btn questions-title collapsed" type="button" data-toggle="collapse"
                                    data-target="#questiontree" aria-expanded="true" aria-controls="questiontree">
                                Tüm Bankalarla Uyumlu Mudur?
                            </button>
                        </div>

                        <div id="questiontree" class="collapse questions-reponse" aria-labelledby="headingtree"
                             data-parent="#frequently-questions">
                            Evet, SSL Sertifikaları tüm bankalarla uyumludur.
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </div>
</section>
<?php
include 'footer.php';
?>


<!-- jquery -->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<!-- bootstrap JavaScript -->
<script src="js/bootstrap.min.js"></script>
<!-- template JavaScript -->
<script src="js/template-scripts.js"></script>
<!-- flickity JavaScript -->
<script src="js/flickity.pkgd.min.js"></script>
<!-- carousel JavaScript -->
<script src="owlcarousel/owl.carousel.min.js"></script>
<!-- parallax JavaScript -->
<script src="js/parallax.min.js"></script>
<!-- mailchamp JavaScript -->
<script src="js/mailchamp.js"></script>
<!-- bootstrap offcanvas -->
<script src="js/bootstrap.offcanvas.min.js"></script>
<!-- touchSwipe JavaScript -->
<script src="js/jquery.touchSwipe.min.js"></script>
</body>

</html>