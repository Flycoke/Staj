<section class="footer-section-banner">
    <div class="container">
        <div class="row free-trial-footer-banner">
            <div class="col-md-6 free-trial-footer-links d-flex mx-auto flex-column">
                <h5 class="free-trial-footer-banner-title">Web Hosting Hizmetlerimizi Keşfetmek İçin</h5>
                <div class="mb-auto"></div>
                <div class="mb-auto">
                    <a class="sign-btn" href="webHosting.php">Tıklayınız</a>
                </div>
                <div class="mt-auto"></div>
            </div>
        </div>
    </div>
</section>
<section class="footer-section">
    <div class="container">
        <div class="row">
            <div class="col-md-9 quiq-links-footer">
                <div class="row">

                    <ul class="col-md-6 quiq-links-footer-ul">
                        <h5 class="quiq-links-footer-title">Hosting</h5>
                        <li><a href="webHosting.php">Web Hosting</a></li>
                        <li><a href="wordpressHosting.php">Wordpress Hosting</a></li>
                        <li><a href="eCommerceHosting.php">E-Ticaret Hosting</a></li>
                        <li><a href="mailHosting.php">Mail Hosting</a></li>
                        <li><a href="dedicatedHosting.php">Bayi Hosting</a></li>
                        <br>
                        <h5 class="quiq-links-footer-title">SSL</h5>
                        <li><h5><a href="ssl.php">SSL Sertifikası</a></h5></li>


                    </ul>


                    <ul class="col-md-6 quiq-links-footer-ul">

                        <h5 class="quiq-links-footer-title">Sunucu</h5>
                        <li><a href="cloudServer.php">Bulut Sunucu</a></li>
                        <li><a href="ecoServer.php">Eco Sunucu</a></li>
                        <li><a href="dedicatedServer.php">Bayi Sunucu</a></li>
                        <li><a href="xtrremeServer.php">Xtreme Sunucu</a></li>
                    </ul>
                    <div class="col-md-12 footer-contact-method">
                        <a href="#">
                        <span>EXORDİTECH YAZILIM BİLİŞİM SANAYİ VE TİCARET LİMİTED ŞİRKETİ
                ORTA MAH. KAVAKLAR CAD. NO: 15 İÇ KAPI NO: 103 ADAPAZARI / SAKARYA</span>
                        </a>
                        <a href="#">
                        <span>MERSİS: 0381091948200001</span>
                        </a>
                        <a href="#">
                            <span>Vergi Kimlik Numarası: 3810919482</span>
                        </a>
                        <a href="#">
                            <span>Ticaret Sicil No: 33668</span>
                        </a>
                        <a href="#">
                            <span>AHMET EMİN KOÇAL</span>
                        </a>
                    </div>

                </div>
            </div>

            <div class="col-md-3">
                <h5 class="quiq-links-footer-title">secure and contact</h5>
                <p class="secure-img-footer-area">
                    <img src="img/iyzico.png" alt=""/>
                    <br>
                    <img src="img/mastercard-visa.png" alt=""/>
                    <br>
                    <img src="img/american-express-troy.png" alt=""/>
                </p>



                <div class="footer-contact-method">

                    <a href="#">
                        <span>Mail</span>
                        <b>info@exorditech.com</b>
                        <i class="fas fa-at"></i>
                    </a>

                    <a href="#">
                        <span>Telefon</span>
                        <b>+90 850 346 5589</b>
                        <i class="fas fa-phone"></i>
                    </a>
                </div>
            </div>
        </div>

        <div class="mr-tp-40 row justify-content-between footer-area-under">
            <div class="col-md-8">
                <a href="#"><img class="footer-logo-blue" src="img/header/logo-w-f.png" alt=""/></a>
                <div class="footer-social-icons">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-youtube"></i></a>
                    <a href="#"><i class="fab fa-dribbble"></i></a>
                    <a href="#"><i class="fab fa-google"></i></a>
                </div>
            </div>

        </div>
        <div class="row justify-content-center final-footer-area mr-tp-40">
            <div class="col-md-4 final-footer-area-text text-center">
                <a href="privacy.php" ">Mesafeli Satış Sözleşmesi</a>
            </div>
            <div class="col-md-4 final-footer-area-text text-center">
                <a href="privacy.php" ">Teslimat ve İade</a>
            </div>
            <div class="col-md-4 final-footer-area-text text-center">
                <a href="privacy.php" ">Gizlilik Sözleşmesi</a>
            </div>

        </div>
        <hr>
        <div class="row justify-content-center final-footer-area mr-tp-10">
            <div class="col-md-12 final-footer-area-text text-center">
                EXORDİTECH YAZILIM BİLİŞİM SANAYİ VE TİCARET LİMİTED ŞİRKETİ © Tüm Hakları Saklıdır
            </div>
        </div>
    </div>
    </div>
</section>