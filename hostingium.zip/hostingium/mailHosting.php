<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Bredh flat responsive HTML & WHMCS hosting and domains template">
    <meta name="author" content="coodiv.net (nedjai mohamed)">
    <link rel="icon" href="favicon.ico">
    <title>bredh | dedicated hosting</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- main css file -->
    <link href="css/main.min.css" rel="stylesheet">

</head>

<body>
<!-- start body -->

<!-- start modal video -->
<div class="modal fade" id="videomodal" tabindex="-1" role="dialog" aria-labelledby="videomodal" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>

                <!-- 16:9 aspect ratio -->
                <div class="embed-responsive embed-responsive-16by9">
                    <iframe class="embed-responsive-item" id="video"></iframe>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end modal video -->

<div class="preloader">
    <!-- start preloader -->
    <div class="preloader-container">
        <svg version="1.1" id="L5" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px"
             y="0px" viewBox="0 0 100 100" enable-background="new 0 0 0 0" xml:space="preserve">
                <circle fill="#675cda" stroke="none" cx="6" cy="50" r="6">
                    <animateTransform attributeName="transform" dur="1s" type="translate" values="0 15 ; 0 -15; 0 15"
                                      repeatCount="indefinite" begin="0.1"/>
                </circle>
            <circle fill="#675cda" stroke="none" cx="30" cy="50" r="6">
                <animateTransform attributeName="transform" dur="1s" type="translate" values="0 10 ; 0 -10; 0 10"
                                  repeatCount="indefinite" begin="0.2"/>
            </circle>
            <circle fill="#675cda" stroke="none" cx="54" cy="50" r="6">
                <animateTransform attributeName="transform" dur="1s" type="translate" values="0 5 ; 0 -5; 0 5"
                                  repeatCount="indefinite" begin="0.3"/>
            </circle>
            </svg>
        <span>loading</span>
    </div>
</div>
<!-- end preloader -->

<div id="coodiv-header" class="d-flex mx-auto flex-column subpages-header moon-edition">
    <div class="bg_overlay_header">
        <div class="video-bg-nuhost-header">
            <div id="video_cover"></div>
            <video autoplay muted loop>
                <source src="media/coodiv-vid.mp4" type="video/mp4">
            </video>
            <span class="video-bg-nuhost-header-bg"></span>
        </div>

        <div id="particles-bg"></div>
        <div class="bg-img-header-new-moon">&nbsp;</div>
        <span class="header-shapes shape-01"></span>
        <span class="header-shapes shape-02"></span>
        <span class="header-shapes shape-03"></span>
    </div>
    <!-- Fixed navbar -->
    <?php
    include 'navbar.php';
    ?>
    <div class="mt-auto header-top-height"></div>
    <main class="container mb-auto">
        <div class="row">
            <div class="col-md-5 d-flex mx-auto flex-column">
                <div class="mb-auto"></div>
                <h3 class="mt-3 main-header-text-title">Mail Hosting
                    <span><br><b>10 GB</b> ve <strong>50 GB</strong> yüksek kapasite seçenekleri</span>
                    <span><strong>Aynı alan adı içinde farklı özellik ve kotalarda hesaplar oluşturabilme</strong> </span>
                    <span>Kişisel, Paylaşılabilir ve Ortak Takvim, Adres Defteri ve Dosyalar</span>
                    <span>Mobil ve Masaüstü Cihazlarda Adres Defteri - Takvim Senkronizasyonu</span>
                </h3>
            </div>
            <div class="col-md-7">
                <div class="breadcrumb-hosting-pages row">
                    <a class="col-md-2" href="webHosting.php">
                        <img src="img/svgs/hosting.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">web hosting</span>
                    </a>

                    <a class="col-md-2" href="wordpressHosting.php">
                        <img src="img/svgs/servers.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">Wordpress Hosting</span>
                    </a>

                    <a class="col-md-2" href="eCommerceHosting.php">
                        <img src="img/svgs/clouds.svg" alt="#"/>
                        <span class="sub-breadcrumb-host-title">E-Ticaret Hosting</span>
                    </a>

                    <a class="col-md-4 active" href="mailHosting.php">
                        <img src="img/svgs/dedicated.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">Mail Hosting</span>
                    </a>

                    <a class="col-md-2" href="dedicatedHosting.php">
                        <img src="img/svgs/dedicated.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">Bayi Hosting</span>
                    </a>
                </div>
            </div>
        </div>

    </main>
    <div class="mt-auto"></div>
</div>

<section class="padding-50-0-10 position-relative">
    <div class="container">
        <h3 class="d-none">pricing table</h3>
        <div class="table-responsive">
            <table class="table table-striped table-dedicated-hosting-container">
                <thead class="table-dedicated-hosting-header">
                <tr>
                    <th scope="col">

                    </th>
                    <th scope="col">
                        <span class="plan-name-dedicated">Mail Standart</span>
                        <span class="price-dedicated second-pricing-table-price monthly">
                            <i class="monthly">$12 <span>/mo</span></i>
                        </span>
                    </th>

                    <th scope="col">
                        <span class="plan-name-dedicated">Mail Pro</span>
                        <span class="price-dedicated second-pricing-table-price monthly">
                            <i class="monthly">$12 <span>/mo</span></i>
                        </span>
                    </th>

                    <th scope="col">
                        <span class="plan-name-dedicated">Mail Kurumsal</span>
                        <span class="price-dedicated second-pricing-table-price monthly">
                            <i class="monthly">$12 <span>/mo</span></i>
                        </span>
                    </th>
                </tr>
                </thead>

                <tbody class="table-dedicated-hosting-body">
                <tr>
                    <th scope="row"><b>E-Posta Başına</b></th>
                    <td><b class="plan-dedicated-config">250 MB</b></td>
                    <td><b class="plan-dedicated-config">10 GB</b></td>
                    <td><b class="plan-dedicated-config">50 GB</b></td>
                </tr>

                <tr>
                    <th scope="row"><b>Anti Spam</b></th>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                </tr>

                <tr>
                    <th scope="row"><b>Anti Virüs</b></th>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                </tr>

                <tr>
                    <th scope="row"><b>IMAP / POP3 / SMTP</b></th>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                </tr>

                <tr>
                    <th scope="row"><b>%100 Uyumluluk</b></th>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                </tr>

                <tr>
                    <th scope="row"><b>Online Yönetim Paneli</b></th>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                </tr>

                <tr>
                    <th scope="row"><b>Telefon Desteği</b></th>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                </tr>

                <tr>
                    <th scope="row"><b>Kişisel Adres Defteri</b></th>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                </tr>

                <tr>
                    <th scope="row"><b>Ortak Adres Defteri</b></th>
                    <td><b class="plan-dedicated-config"></b></td>
                    <td><b class="plan-dedicated-config"></b></td>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                </tr>

                <tr>
                    <th scope="row"><b>Kişisel ve Paylaştırılabilir Takvim</b></th>
                    <td><b class="plan-dedicated-config"></b></td>
                    <td><b class="plan-dedicated-config"></b></td>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                </tr>

                <tr>
                    <th scope="row"><b>Kişisel ve Ortak Dosya Alanı</b></th>
                    <td><b class="plan-dedicated-config"></b></td>
                    <td><b class="plan-dedicated-config"></b></td>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                </tr>

                <tr>
                    <th scope="row"><b>Mobil Senkronizasyon</b></th>
                    <td><b class="plan-dedicated-config"></b></td>
                    <td><b class="plan-dedicated-config"></b></td>
                    <td><b class="plan-dedicated-config"><i class="fas fa-check-circle"></i></b></td>
                </tr>

                <tr>
                    <th scope="row"></th>
                    <td><a class="plan-dedicated-order-button" href="#">satın al</a></td>
                    <td><a class="plan-dedicated-order-button" href="#">satın al</a></td>
                    <td><a class="plan-dedicated-order-button" href="#">satın al</a></td>
                </tr>

                </tbody>
            </table>
        </div>

    </div>
</section>

<section class="section-wth-amwaj">
    <div class="bg_overlay_section-amwaj">
        <img src="img/bg/b_bg_02.jpg" alt="img-bg">
    </div>

    <div class="container">
        <h5 class="title-default-coodiv-tree">High Performance Compute Instances Activate in seconds. Online 24x7<span>Mail Hosting Paketleri Ortak Özellikleri</span>
        </h5>

        <div class="row justify-content-left mr-tp-80">
            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-002-plug"></i>
                    <h5>Yüksek Boyutlu Disk Alanı</h5>
                    <p>Pro ve Kurumsal Hesaplarda uzun süre iletilerinizi silmeden biriktirebileceğiniz depolama
                        alanı</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-025-router"></i>
                    <h5>Adres Defteri</h5>
                    <p>Kişi listesiyle alıcılarınızı daha sonra kolayca e-posta gönderebilmek için kaydedebilirsiniz</p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-021-virtual-reality"></i>
                    <h5>Güvenli İletişim</h5>
                    <p>Standart Anti-Spam ve Virüs koruması sayesinde güvenli iletişim kurabilirsiniz.</p>
                </div>
            </div>
        </div>

        <div class="row justify-content-left mr-tp-30">
            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-032-sata"></i>
                    <h5>Online Yönetim Paneli</h5>
                    <p>Gelişmiş Türkçe arayüz sayesinde e-posta yönetiminizi kolayca gerçekleştirebilirsiniz</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-037-cable"></i>
                    <h5>E-Postalarınız Hep Sizinle</h5>
                    <p>E-postalarınızı her zaman, her yerde akıllı telefonunuz üzerinden de takip edebilirsiniz</p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-045-car-key"></i>
                    <h5>%100 Uyumlu IMAP/POP3/SMTP</h5>
                    <p>Outlook, Apple Mail, eM Client, Thunderbird gibi popüler e-posta programlarıyla tam
                        uyumludur.Otomatik Hesap Kurulumu desteklenir.</p>
                </div>
            </div>
        </div>

    </div>
</section>

<section class="padding-100-0 with-top-border">
    <div class="container">
        <h5 class="title-default-coodiv-two">Sıkça Sorulan Sorular</h5>

        <div class="row justify-content-center mr-tp-40">
            <div class="col-md-9">

                <div class="accordion" id="frequently-questions">

                    <div class="questions-box">
                        <div id="headingOne">
                            <button class="btn questions-title" type="button" data-toggle="collapse"
                                    data-target="#questionone" aria-expanded="true" aria-controls="questionone">
                                E-mail Hosting Nedir ?
                            </button>
                        </div>

                        <div id="questionone" class="collapse show questions-reponse" aria-labelledby="headingOne"
                             data-parent="#frequently-questions">
                            E-mail hosting, e-mail sunucularında çalışan bir servistir. Basitçe özetlemek gerekirse,
                            sahip olduğunuz domain ile bir e-mail adresi edinmek istiyorsanız, e-mail hosting servisine
                            ihtiyaç duyarsınız. E-mail hosting servisini Natro'dan alarak, alan adınız ile
                            kullanabileceğiniz e-posta hesaplarına sahip olmanın yanı sıra, anti-virus / anti-spam gibi
                            özelliklerden de ücretsiz olarak yararlanırsınız.
                        </div>
                    </div>

                    <div class="questions-box">
                        <div id="headingtwo">
                            <button class="btn questions-title collapsed" type="button" data-toggle="collapse"
                                    data-target="#questiontwo" aria-expanded="true" aria-controls="questiontwo">
                                Profesyonel e-mail adresinin ücretsiz e-mail adreslerine göre avantajları nelerdir? ?
                            </button>
                        </div>

                        <div id="questiontwo" class="collapse questions-reponse" aria-labelledby="headingtwo"
                             data-parent="#frequently-questions">
                            Profesyonel e-mail servisleri ile, işinizi profesyonel ve kurumsal olarak temsil edecek bir
                            e-posta adresine sahip olurken, bir çok ek özellikten ücretsiz olarak faydalanırsınız.
                            Üstelik ücretsiz olarak edineceğiniz bir e-posta hesabından çok daha yüksek kapasitede
                            depolama alanı elde edersiniz.
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </div>
</section>


<?php
include 'footer.php';
?>

<!-- jquery -->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<!-- bootstrap JavaScript -->
<script src="js/bootstrap.min.js"></script>
<!-- template JavaScript -->
<script src="js/template-scripts.js"></script>
<!-- flickity JavaScript -->
<script src="js/flickity.pkgd.min.js"></script>
<!-- carousel JavaScript -->
<script src="owlcarousel/owl.carousel.min.js"></script>
<!-- parallax JavaScript -->
<script src="js/parallax.min.js"></script>
<!-- mailchamp JavaScript -->
<script src="js/mailchamp.js"></script>
<!-- bootstrap offcanvas -->
<script src="js/bootstrap.offcanvas.min.js"></script>
<!-- touchSwipe JavaScript -->
<script src="js/jquery.touchSwipe.min.js"></script>

<!-- seconde style additionel JavaScript -->
<script src="js/particles-code.js"></script>
<script src="js/particles.js"></script>
<script src="js/smoothscroll.js"></script>
</body>

</html>