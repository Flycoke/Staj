<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Bredh flat responsive HTML & WHMCS hosting and domains template">
    <meta name="author" content="coodiv.net (nedjai mohamed)">
    <link rel="icon" href="favicon.ico">
    <title>bredh | web hosting</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- main css file -->
    <link href="css/main.min.css" rel="stylesheet">
    <!-- main css file -->
    <link href="css/style.css" rel="stylesheet">

</head>

<body>
<!-- start body -->

<div class="preloader">
    <!-- start preloader -->
    <div class="preloader-container">
        <svg version="1.1" id="L5" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px"
             y="0px" viewBox="0 0 100 100" enable-background="new 0 0 0 0" xml:space="preserve">
                <circle fill="#675cda" stroke="none" cx="6" cy="50" r="6">
                    <animateTransform attributeName="transform" dur="1s" type="translate" values="0 15 ; 0 -15; 0 15"
                                      repeatCount="indefinite" begin="0.1"/>
                </circle>
            <circle fill="#675cda" stroke="none" cx="30" cy="50" r="6">
                <animateTransform attributeName="transform" dur="1s" type="translate" values="0 10 ; 0 -10; 0 10"
                                  repeatCount="indefinite" begin="0.2"/>
            </circle>
            <circle fill="#675cda" stroke="none" cx="54" cy="50" r="6">
                <animateTransform attributeName="transform" dur="1s" type="translate" values="0 5 ; 0 -5; 0 5"
                                  repeatCount="indefinite" begin="0.3"/>
            </circle>
            </svg>
        <span>loading</span>
    </div>
</div>
<!-- end preloader -->

<div id="coodiv-header" class="d-flex mx-auto flex-column subpages-header moon-edition">
    <div class="bg_overlay_header">
        <div class="video-bg-nuhost-header">
            <div id="video_cover"></div>
            <video autoplay muted loop>
                <source src="media/coodiv-vid.mp4" type="video/mp4">
            </video>
            <span class="video-bg-nuhost-header-bg"></span>
        </div>

        <div id="particles-bg"></div>
        <div class="bg-img-header-new-moon">&nbsp;</div>
        <span class="header-shapes shape-01"></span>
        <span class="header-shapes shape-02"></span>
        <span class="header-shapes shape-03"></span>
    </div>
    <!-- Fixed navbar -->
    <?php
    include 'navbar.php';
    ?>
    <div class="mt-auto header-top-height"></div>
    <main class="container mb-auto">
        <div class="row">
            <div class="col-md-5 d-flex mx-auto flex-column">
                <div class="mb-auto"></div>
                <h3 class="mt-3 main-header-text-title">Web Hosting
                    <span><br><strong>Sınırsız</strong> Hosting</span>
                    <span><strong>Sınırsız</strong> SSD Disk Alanı</span>
                    <span><strong>Sınırsız</strong> Trafik</span>
                </h3>
            </div>
            <div class="col-md-7">
                <div class="breadcrumb-hosting-pages row">
                    <a class="col-md-3 active" href="cloudServer.php">
                        <img src="img/svgs/hosting.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">bulut sunucu</span>
                    </a>

                    <a class="col-md-3" href="ecoServer.php">
                        <img src="img/svgs/servers.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">eco sunucu</span>
                    </a>

                    <a class="col-md-3" href="dedicatedServer.php">
                        <img src="img/svgs/clouds.svg" alt="#"/>
                        <span class="sub-breadcrumb-host-title">bayi sunucu</span>
                    </a>

                    <a class="col-md-3" href="xtrremeServer.php">
                        <img src="img/svgs/dedicated.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">Xtreme Sunucu</span>
                    </a>
                </div>
            </div>
        </div>
    </main>
    <div class="mt-auto"></div>
</div>

<section class="padding-100-0-10 position-relative">
    <div class="container">
        <div class="banner-servers-box">
            <div class="counter-placeholder"></div>
            <div class="banner-text-left">
                <h5>Fırsat Sunucuları</h5>
                <p>En iyi fiyat avantajı</p>
            </div>
        </div>

        <div class="row justify-content-left server-tabls-head">
            <div class="col-md-2">paket</div>
            <div class="col-md-2">ram</div>
            <div class="col-md-2">disk</div>
            <div class="col-md-2">raid</div>
            <div class="col-md-4">fiyat</div>
        </div>

        <div class="server-tabls-body">
            <div class="row justify-content-left server-tabls-row">
                <div class="col-md-2"><span class="server-spects-for-mobile">Paket</span> <b>Fırsat 1</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">RAM</span> <b>8 GB</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Disk</span> <b>240 GB</b> SSD</div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Raid</span> <b>yok</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Fiyat</span> <b>$12</b>/mo</div>
                <div class="col-md-2"><a class="server-order-button" href="#">Satın Al</a></div>
            </div>

            <div class="row justify-content-left server-tabls-row best-one">
                <div class="col-md-2"><span class="server-spects-for-mobile">Paket</span> <b>Fırsat 2</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">RAM</span> <b>8 GB</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Disk</span> <b>2 x 240 GB</b> SSD</div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Raid</span> <b>Raid 1</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Fiyat</span> <b>$12</b>/mo</div>
                <div class="col-md-2"><a class="server-order-button" href="#">Satın Al</a></div>
            </div>

            <div class="row justify-content-left server-tabls-row">
                <div class="col-md-2"><span class="server-spects-for-mobile">Paket</span> <b>Fırsat 3</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">RAM</span> <b>8 GB</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Disk</span> <b>2 x 240 GB</b> SSD</div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Raid</span> <b>Raid 1</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Fiyat</span> <b>$12</b>/mo</div>
                <div class="col-md-2"><a class="server-order-button" href="#">Satın Al</a></div>
            </div>
            <div class="row justify-content-left server-tabls-row">
                <div class="col-md-2"><span class="server-spects-for-mobile">Paket</span> <b>Fırsat 4</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">RAM</span> <b>8 GB</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Disk</span> <b>2 x 240 GB</b> SSD</div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Raid</span> <b>Raid 1</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Fiyat</span> <b>$12</b>/mo</div>
                <div class="col-md-2"><a class="server-order-button" href="#">Satın Al</a></div>
            </div>
        </div>
    </div>
</section>

<section class="padding-100-0-10 position-relative">
    <div class="container">
        <div class="banner-servers-box">
            <div class="counter-placeholder"></div>
            <div class="banner-text-left">
                <h5>Bayi Sunucuları</h5>
                <p>İhtiyacınıza uygun Bayi Sunucunuzu bulun</p>
            </div>
        </div>

        <div class="row justify-content-left server-tabls-head">
            <div class="col-md-2">paket</div>
            <div class="col-md-2">ram</div>
            <div class="col-md-2">disk</div>
            <div class="col-md-2">raid</div>
            <div class="col-md-4">fiyat</div>
        </div>

        <div class="server-tabls-body">
            <div class="row justify-content-left server-tabls-row">
                <div class="col-md-2"><span class="server-spects-for-mobile">Paket</span> <b>Bayi 1</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">RAM</span> <b>16 GB</b><br><span
                            class="span-info-servers">Max 64 GB</span></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Disk</span> <b>480 GB</b> SSD<br><span
                            class="span-info-servers">Max 4 Disk</span></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Raid</span> <b>Yok</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Fiyat</span> <b>$12</b>/mo</div>
                <div class="col-md-2"><a class="server-order-button" href="#">Satın Al</a></div>
            </div>

            <div class="row justify-content-left server-tabls-row best-one">
                <div class="col-md-2"><span class="server-spects-for-mobile">Paket</span> <b>Bayi 2</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">RAM</span> <b>16 GB</b><br><span
                            class="span-info-servers">Max 64 GB</span></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Disk</span> <b>1 TB</b> SATA<br><span
                            class="span-info-servers">Max 4 Disk</span></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Raid</span> <b>Yok</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Fiyat</span> <b>$12</b>/mo</div>
                <div class="col-md-2"><a class="server-order-button" href="#">Satın Al</a></div>
            </div>

            <div class="row justify-content-left server-tabls-row">
                <div class="col-md-2"><span class="server-spects-for-mobile">Paket</span> <b>Bayi 3</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">RAM</span> <b>16 GB</b><br><span
                            class="span-info-servers">Max 64 GB</span></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Disk</span> <b>2 x 480 GB</b> SSD<br><span
                            class="span-info-servers">Max 4 Disk</span></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Raid</span> <b>Raid 1 - 10</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Fiyat</span> <b>$12</b>/mo</div>
                <div class="col-md-2"><a class="server-order-button" href="#">Satın Al</a></div>
            </div>
            <div class="row justify-content-left server-tabls-row">
                <div class="col-md-2"><span class="server-spects-for-mobile">Paket</span> <b>Bayi 4</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">RAM</span> <b>16 GB</b><br><span
                            class="span-info-servers">Max 64 GB</span></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Disk</span> <b>2 x 1 TB</b> HDD<br><span
                            class="span-info-servers">Max 4 Disk</span></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Raid</span> <b>Raid 1 - 10</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Fiyat</span> <b>$12</b>/mo</div>
                <div class="col-md-2"><a class="server-order-button" href="#">Satın Al</a></div>
            </div>
        </div>
    </div>
</section>

<section class="padding-100-0-10 position-relative">
    <div class="container">
        <div class="banner-servers-box">
            <div class="counter-placeholder"></div>
            <div class="banner-text-left">
                <h5>Xtreme Sunucuları</h5>
                <p>İhtiyacınıza uygun Xtreme Sunucunuzu bulun</p>
            </div>
        </div>

        <div class="row justify-content-left server-tabls-head">
            <div class="col-md-2">paket</div>
            <div class="col-md-2">ram</div>
            <div class="col-md-2">disk</div>
            <div class="col-md-2">raid</div>
            <div class="col-md-4">fiyat</div>
        </div>

        <div class="server-tabls-body">
            <div class="row justify-content-left server-tabls-row">
                <div class="col-md-2"><span class="server-spects-for-mobile">Paket</span> <b>Bayi 1</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">RAM</span> <b>32 GB</b><br><span
                            class="span-info-servers">Max 768 GB</span></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Disk</span> <b>2 x 300 GB</b> <br><span
                            class="span-info-servers">10K SAS Disk</span></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Raid</span> <b>RAID 1 - 5 - 10</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Fiyat</span> <b>$12</b>/mo</div>
                <div class="col-md-2"><a class="server-order-button" href="#">Satın Al</a></div>
            </div>

            <div class="row justify-content-left server-tabls-row best-one">
                <div class="col-md-2"><span class="server-spects-for-mobile">Paket</span> <b>Bayi 2</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">RAM</span> <b>32 GB</b><br><span
                            class="span-info-servers">Max 768GB</span></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Disk</span> <b>2 x 240 GB</b><br><span
                            class="span-info-servers">SSD Disk</span></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Raid</span> <b>RAID 1 - 5 - 10</b></div>
                <div class="col-md-2"><span class="server-spects-for-mobile">Fiyat</span> <b>$12</b>/mo</div>
                <div class="col-md-2"><a class="server-order-button" href="#">Satın Al</a></div>
            </div>
        </div>
    </div>
    </div>
</section>


<section class="section-wth-amwaj">
    <div class="bg_overlay_section-amwaj">
        <img src="img/bg/b_bg_02.jpg" alt="img-bg">
    </div>

    <div class="container">
        <h5 class="title-default-coodiv-tree">High Performance Compute Instances Activate in seconds. Online 24x7<span>Üstün Yönetim Özellikleri</span>
        </h5>

        <div class="row justify-content-left mr-tp-80">
            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-002-plug"></i>
                    <h5>Tam Bayi Sunucu Kontrolü</h5>
                    <p>Dedicated sunucunuzu kontrol panelinden veya API üzerinden yeniden başlatın, yedekleyin, yeniden
                        kurun.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-025-router"></i>
                    <h5>Genişletilebilir Kaynaklar</h5>
                    <p>Donanım ihtiyaçlarınız doğrultusunda dedicated server kaynaklarını kapasite kapsamında
                        dilediğiniz gibi artırın.</p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-021-virtual-reality"></i>
                    <h5>Yedekli Network Altyapısı</h5>
                    <p>Tüm risk senaryoları için yedeklenmiş network altyapı sayesinde beklenmedik süprizler
                        yaşamayın.</p>
                </div>
            </div>
        </div>

        <div class="row justify-content-left mr-tp-30">
            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-032-sata"></i>
                    <h5>1 Gbit Trafik</h5>
                    <p>1 Gbit bant genişliği ile herhangi bir trafik limiti ya da ek maliyet kaygısı taşımadan dedicated
                        server yönetin.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-037-cable"></i>
                    <h5>Çoklu Disk (RAID) Desteği</h5>
                    <p>8 adete kadar diski aynı anda kullanarak veri yedekliliğinizi yükseltin ve depolama kapasitenizi
                        maksimuma çıkartın.</p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="features-box-style-two">
                    <i class="e-flaticon-045-car-key"></i>
                    <h5>Ücretsiz Kontrol Paneli</h5>
                    <p>Dedicated server ile birlikte ücretsiz sunduğumuz CyberPanel kontrol paneli ile, web sitelerinizi
                        kolayca yönetin.</p>
                </div>
            </div>
        </div>

    </div>
</section>

<section class="padding-100-0 with-top-border">
    <div class="container">
        <h5 class="title-default-coodiv-two">Sıkça Sorulan Sorular</h5>

        <div class="row justify-content-center mr-tp-40">
            <div class="col-md-9">

                <div class="accordion" id="frequently-questions">

                    <div class="questions-box">
                        <div id="headingOne">
                            <button class="btn questions-title" type="button" data-toggle="collapse"
                                    data-target="#questionone" aria-expanded="true" aria-controls="questionone">
                                Fırsat Sunucu nedir ?
                            </button>
                        </div>

                        <div id="questionone" class="collapse show questions-reponse" aria-labelledby="headingOne"
                             data-parent="#frequently-questions">
                            Fırsat sunucusu, yeniden değerlendirme kapsamında satışa sunulan ve en iyi fiyat/performans
                            için özel olarak konfigüre edilmiş uygun maliyetli sunucu ürünüdür.
                        </div>
                    </div>

                    <div class="questions-box">
                        <div id="headingtwo">
                            <button class="btn questions-title collapsed" type="button" data-toggle="collapse"
                                    data-target="#questiontwo" aria-expanded="true" aria-controls="questiontwo">
                                Bayi Sunucu nedir ?
                            </button>
                        </div>

                        <div id="questiontwo" class="collapse questions-reponse" aria-labelledby="headingtwo"
                             data-parent="#frequently-questions">
                            Bayi Sunucu, fiziksel bir sunucunun tüm kaynaklarının (yazılımsal ve donanımsal) tek bir
                            kullanıcıya tahsis edildiği sunucu kiralama çözümüdür. Kiraladığınız sunucuya ihtiyacınız
                            olan işletim sistemini kurabilir, sunucunuzu dilediğiniz hosting kontrol paneli ile
                            yönetebilirsiniz.
                        </div>
                    </div>

                    <div class="questions-box">
                        <div id="headingtree">
                            <button class="btn questions-title collapsed" type="button" data-toggle="collapse"
                                    data-target="#questiontree" aria-expanded="true" aria-controls="questiontree">
                                Xtreme Sunucu nedir ve kimler için uygundur ?
                            </button>
                        </div>

                        <div id="questiontree" class="collapse questions-reponse" aria-labelledby="headingtree"
                             data-parent="#frequently-questions">
                            Daha fazla kaynak gerektiren özel projeleriniz için, yüksek spesifikasyonlara sahip
                            donanımsal ve yazılımsal yapılandırma seçenekleri sunan, esnek bir fiziksel sunucu kiralama
                            çözümüdür. Yüksek kaynak ihtiyacı olan ve sunucu kaynağını paylaşımsız olarak kullanmak
                            isteyen kullanıcılar için idealdir.
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </div>
</section>


<?php
include 'footer.php';
?>

<!-- jquery -->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<!-- bootstrap JavaScript -->
<script src="js/bootstrap.min.js"></script>
<!-- template JavaScript -->
<script src="js/template-scripts.js"></script>
<!-- flickity JavaScript -->
<script src="js/flickity.pkgd.min.js"></script>
<!-- carousel JavaScript -->
<script src="owlcarousel/owl.carousel.min.js"></script>
<!-- parallax JavaScript -->
<script src="js/parallax.min.js"></script>
<!-- mailchamp JavaScript -->
<script src="js/mailchamp.js"></script>
<!-- bootstrap offcanvas -->
<script src="js/bootstrap.offcanvas.min.js"></script>
<!-- touchSwipe JavaScript -->
<script src="js/jquery.touchSwipe.min.js"></script>

<!-- seconde style additionel JavaScript -->
<script src="js/particles-code.js"></script>
<script src="js/particles.js"></script>
<script src="js/smoothscroll.js"></script>
</body>

</html>