<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Bredh flat responsive HTML & WHMCS hosting and domains template">
    <meta name="author" content="coodiv.net (nedjai mohamed)">
    <link rel="icon" href="favicon.ico">
    <title>Hostingium | Alan Adı Sorgulama</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- main css file -->
    <link href="css/main.min.css" rel="stylesheet">


</head>

<body>
<!-- start body -->

<div class="preloader">
    <!-- start preloader -->
    <div class="preloader-container">
        <svg version="1.1" id="L5" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px"
             y="0px" viewBox="0 0 100 100" enable-background="new 0 0 0 0" xml:space="preserve">
                <circle fill="#675cda" stroke="none" cx="6" cy="50" r="6">
                    <animateTransform attributeName="transform" dur="1s" type="translate" values="0 15 ; 0 -15; 0 15"
                                      repeatCount="indefinite" begin="0.1"/>
                </circle>
            <circle fill="#675cda" stroke="none" cx="30" cy="50" r="6">
                <animateTransform attributeName="transform" dur="1s" type="translate" values="0 10 ; 0 -10; 0 10"
                                  repeatCount="indefinite" begin="0.2"/>
            </circle>
            <circle fill="#675cda" stroke="none" cx="54" cy="50" r="6">
                <animateTransform attributeName="transform" dur="1s" type="translate" values="0 5 ; 0 -5; 0 5"
                                  repeatCount="indefinite" begin="0.3"/>
            </circle>
            </svg>
        <span>loading</span>
    </div>
</div>
<!-- end preloader -->

<div id="coodiv-header" class="d-flex mx-auto flex-column subpages-header moon-edition">
    <div class="bg_overlay_header">
        <div class="video-bg-nuhost-header">
            <div id="video_cover"></div>
            <video autoplay muted loop>
                <source src="media/coodiv-vid.mp4" type="video/mp4">
            </video>
            <span class="video-bg-nuhost-header-bg"></span>
        </div>

        <div id="particles-bg"></div>
        <div class="bg-img-header-new-moon">&nbsp;</div>
        <span class="header-shapes shape-01"></span>
        <span class="header-shapes shape-02"></span>
        <span class="header-shapes shape-03"></span>
    </div>
    <!-- Fixed navbar -->
    <?php
    include 'navbar.php';
    ?>
    <div class="mt-auto header-top-height"></div>
    <main class="container mb-auto">
        <h3 class="mt-3 main-header-text-title"><span>Her Şey Harika Bir Alan Adı İle Başlar</span> alan adı sorgulama
        </h3>
        <div class="row justify-content-center">
            <form id="domain-search-header" class="col-md-6">
                <i class="fas fa-globe"></i>
                <input type="text" placeholder="şimdi alan adınızı arayın" id="domain" name="domains">
                <span class="inline-button-domain-order">
	            <button data-toggle="tooltip" data-placement="left" title="transfer" id="transfer-btn" type="submit"
                        name="transfer" value="Transfer"><i class="fas fa-undo"></i></button>
	            <button data-toggle="tooltip" data-placement="left" title="search" id="search-btn" type="submit"
                        name="submit" value="Search"><i class="fas fa-search"></i></button>
	            </span>
            </form>
        </div>
    </main>
    <div class="mt-auto"></div>
</div>

<section class="padding-50-0-10 position-relative">
    <div class="container">
        <div class="row justify-content-left box-features-tree-container">
            <div class="col-md-12 box-features-tree">
                <i class="fas fa-chess-bishop"></i>
                <h5>Domain Sorgulama Nedir?</h5>
                <p>Kayıt etmek istediğiniz bir alan adının daha önce tescil edilip edilmediğini öğrenmenizi ve kayıt
                    için müsait olan domaini belirlemenizi sağlayan işleme domain sorgulama denir. Üst kısımda bulunan
                    alan adı sorgulama alanından aklınızdaki domaini kontrol edebilir, kayıt işlemini hemen
                    gerçekleştirebilirsiniz.</p>
            </div>
        </div>
</section>

<section>
    <div class="container">
        <div class="row justify-content-between mr-tp-50">
            <div class="table-responsive">
                <table class="table pricing_table_domain">
                    <thead>
                    <tr>
                        <th>domain</th>
                        <th>1 year</th>
                        <th>renew</th>
                        <th>transfer</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <th>.com</th>
                        <td>$9.95</td>
                        <td>$9.95</td>
                        <td>$9.95</td>
                        <td><a href="#">buy</a></td>
                    </tr>
                    <tr>
                        <th>.xyz</th>
                        <td>$9.50</td>
                        <td>$9.50</td>
                        <td>$9.50</td>
                        <td><a href="#">buy</a></td>
                    </tr>
                    <tr>
                        <th>.net</th>
                        <td>$9.95</td>
                        <td>$9.95</td>
                        <td>$9.95</td>
                        <td><a href="#">buy</a></td>
                    </tr>
                    <tr>
                        <th>.online</th>
                        <td>$10.00</td>
                        <td>$10.00</td>
                        <td>$10.00</td>
                        <td><a href="#">buy</a></td>
                    </tr>
                    <tr>
                        <th>.com.tr</th>
                        <td>$10.00</td>
                        <td>$10.00</td>
                        <td>$10.00</td>
                        <td><a href="#">buy</a></td>
                    </tr>
                    <tr>
                        <th>.info</th>
                        <td>$8.98</td>
                        <td>$8.98</td>
                        <td>$8.98</td>
                        <td><a href="#">buy</a></td>
                    </tr>
                    <tr>
                        <th>.orgl</th>
                        <td>$11.25</td>
                        <td>$11.25</td>
                        <td>$11.25</td>
                        <td><a href="#">buy</a></td>
                    </tr>
                    <tr>
                        <th>.top</th>
                        <td>$9.50</td>
                        <td>$9.50</td>
                        <td>$9.50</td>
                        <td><a href="#">buy</a></td>
                    </tr>
                    <tr>
                        <th>.store</th>
                        <td>$9.95</td>
                        <td>$9.95</td>
                        <td>$9.95</td>
                        <td><a href="#">buy</a></td>
                    </tr>
                    <tr>
                        <th>.site</th>
                        <td>$10.00</td>
                        <td>$10.00</td>
                        <td>$10.00</td>
                        <td><a href="#">buy</a></td>
                    </tr>

                    </tr>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</section>
<section class="padding-50-0-10 position-relative">
    <div class="container">
        <div class="row justify-content-left box-features-tree-container">
            <div class="col-md-12 box-features-tree">
                <h5>Alan Adını Seçerken Nelere Dikkat Etmeliyim?</h5><br>
                <p>Bir web sitesi açmak için öncelikle bir domain satın almak gereklidir. Seçilen alan adı, mümkün
                    olduğunca kısa, anlamlı ve akılda kalıcı olmalıdır. Her dilde kolayca okunabilen bir yapıda alan adı
                    kayıt etmek, ilgili web sitesine farklı ülke ve bölgelerden de kolay erişim sağlanması için fayda
                    sağlayacaktır. Kayıt edilecek alan adı, yayınlanacak web sitesi içeriği ile uyumlu olmalı ve site
                    ile alakalı anahtar kelimeleri içermelidir. Ayrıca kayıt öncesi, belirlenen alan adı ile ilgili
                    mevcutta bir marka tescili yapılıp yapılmadığını sorgulamak, daha sonra karşılaşılabilecek telif
                    sorunları ve yasal problemlerin önüne geçmek için de faydalı olacaktır.</p>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row justify-content-left box-features-tree-container">
            <div class="col-md-12 box-features-tree">
                <h5>Yatırım Amaçlı Domain Seçerken Nelere Dikkat Etmeliyim?</h5><br>
                <p>Yalnızca web sitesi yayınlamak için değil, yatırım amaçlı da domain kayıt edilebilir. Potansiyel
                    olarak değerlendirilen ve yatırım amaçlı kayıt edilen domainlerde öncelikle kelime analizi
                    yapılmalı, kayıt edilecek domainin içerdiği kelimelerin arama hacimleri ve popülaritesi incelenmeli.
                    Domainin değerini belirleyen en önemli ektenlerden birisi olan karakter sayısına dikkat edilmeli,
                    akılda kalıcı ve kolay okunabilen jenerik kelimeler tercih edilmelidir. Gündem konuları ve popüler
                    aramalar, yatırım amaçlı bir domain kayıt etmek için en önemli başlangıç noktalarıdır. Yatırım
                    amaçlı kayıt edilen alan adlarını, Natro Satılık Domain platformu üzerinden satışa çıkartarak domain
                    başına 1.000$’a varan kazanç elde etmek mümkündür.</p>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row justify-content-left box-features-tree-container">
            <div class="col-md-12 box-features-tree">
                <h5>Hangi Domain Uzantısını Tercih Etmeliyim?</h5><br>
                <p>Alan adı satın alma aşamasında genellikle ilk tercih .com domain olmakla birlikte, günümüzde kısa ve
                    anlamlı kelime kombinasyonlarında henüz kayıt edilmemiş bir .com domain bulmak oldukça zordur. Bu
                    noktada işinizi ve içeriğinizi doğrudan ifade eden yeni domain uzantılarını tercih edebilirsiniz.
                    Örneğin; bir e-ticaret sitesi için .shop domain, .market domain, kurumsal web siteleri için .ltd
                    domain gibi alternatifler değerlendirilebilir. Türkiye pazarında faaliyet gösteren bir işletme veya
                    markanın .com.tr domain uzantısını da kayıt ederek markasını koruma altına alması önemlidir.</p>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row justify-content-left box-features-tree-container">
            <div class="col-md-12 box-features-tree">
                <h5>En Popüler Domain (Alan Adı) Uzantıları Hangileridir?</h5><br>
                <p>ICANN verilerine göre dünyanın en popüler 3 alan adı uzantısı; .com domain, .net domain ve .org
                    domain olarak öne çıkmaktadır. Ülkemizde .com.tr domain, işletmelerin ve marka sahiplerinin belge
                    ile kayıt edebildiği bir alan adı uzantısıdır. 2020 yılının ikinci çeyrek verilerine göre dünyada
                    kayıtlı toplam 370 milyondan fazla alan adı bulunmaktadır. Bunun 148 milyondan fazlası .com
                    domain’dir. Uzantılara göre domain fiyatları farklılık göstermekle birlikte en ucuz domain kayıt
                    işlemini natro.com üzerinden gerçekleştirebilirsiniz. Alan adı fiyatları incelendiğinde söz konusu
                    rakamlar yıllık domain ücretlerini ifade etmektedir.</p>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row justify-content-left box-features-tree-container">
            <div class="col-md-12 box-features-tree">
                <h5>Domain Nedir?</h5><br>
                <p>Domain, bir web sitesinin internet üzerindeki adı ve aynı zamanda adresidir. Ülkemizde alan adı
                    olarak da tanımlanmaktadır. Web sitelerine ulaşmak için hatırlanması oldukça zor olan 78.164.218.85
                    gibi ip adreslerinin yerine kullanılan ve akılda kalıcı olmasını sağlayan isimlere domain denir.
                    Alan adı en az 1 yıl, en fazla 10 yıla kadar kayıt edilerek kiralanan bir hizmettir ve kayıt süresi
                    sonunda yenileme işlemi yapıldığı sürece domain sahipliği korunur. Dünyanın ilk alan adı 15 Mart
                    1985 tarihinde symbolics.com olarak kayıt edilmiştir. Türkiye’nin ülke uzantılı alan adı COM.TR
                    domain, BTK tarafından yönetilerek belge karşılığı tahsis edilmekte ve en fazla 5 yıl süre ile kayıt
                    edilebilmektedir.</p>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row justify-content-left box-features-tree-container">
            <div class="col-md-12 box-features-tree">
                <h5>.Com Domain Kayıt Fiyatı Nedir?</h5><br>
                <p>.com domain uzantısı Verisign tarafından yönetilmekte, ülkemizde ve dünyada çeşitli fiyat
                    aralıklarında kayıt edilmektedir. En popüler alan adı uzantısı olan .com domain ülkemizde en uygun
                    kayıt fiyatı ile yılda sadece 4,99$’a natro.com üzerinden kayıt edilebilmektedir. Dünya genelinde en
                    çok tercih edilen ve en fazla kayıt edilen domain uzantısı olan .com alan adını, Natro üzerinden
                    kayıt eden kullanıcılar, aynı kelimenin .XYZ domin uzantısına da ÜCRETSİZ sahip olabilmektedir.
                    Kayıt edilen tüm domainler Natro tarafından sunulan ÜCRETSİZ bir servis olan Transfer Kilidi ile
                    koruma altına alınır.</p>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row justify-content-left box-features-tree-container">
            <div class="col-md-12 box-features-tree">
                <h5>Web Sitenizi Yayınlayın</h5><br>
                <p>Alan adı kayıt işlemi sonrasında web sitesi yayınlamak için bir hosting sahibi olmak gerekmektedir.
                    Bu aşamada tercih edilecek hosting hizmetine, web sitesi tercihine göre karar verilebilmektedir. Bir
                    blog, içerik yada kişisel web sitesi için WordPress Hosting tercih ederek kolayca ve basit bir
                    şekilde sitenizi yayınlayabilir ve hemen içerik üretmeye başlayabilirsiniz. Bunun yanı sıra
                    NatroSite ile hiç bir web tasarım veya teknik bilgiye ihtiyaç duymadan dakikalar içerisinde kolayca
                    hazır web sitesi sahibi olabilirsiniz. İşletmelerin dijital dönüşüm yatırımı yaparak bir web sitesi
                    sahibi olmaları, ürün ve hizmetlerini daha fazla kişiye ulaştırmalarını ve dönüşümleri artırmalarını
                    sağlamaktadır.</p>
            </div>
        </div>
    </div>
</section>


<section class="padding-100-0 with-top-border">
    <div class="container">
        <h5 class="title-default-coodiv-two">Sıkça Sorulan Sorular</h5>

        <div class="row justify-content-center mr-tp-40">
            <div class="col-md-9">

                <div class="accordion" id="frequently-questions">

                    <div class="questions-box">
                        <div id="headingOne">
                            <button class="btn questions-title" type="button" data-toggle="collapse"
                                    data-target="#questionone" aria-expanded="true" aria-controls="questionone">
                                Domain (alan adı) nedir?
                            </button>
                        </div>

                        <div id="questionone" class="collapse show questions-reponse" aria-labelledby="headingOne"
                             data-parent="#frequently-questions">
                            Domain, bir web sitesinin internet üzerindeki adı ve aynı zamanda adresidir. Web sitelerine
                            ulaşmak için hatırlanması oldukça zor olan ip adreslerinin yerine kullanılan, akılda kalıcı
                            isimlere domain denir. Ülkemizde alan adı olarak da bilinen domain, 1 yıldan 10 yıla kadar
                            kayıt edilerek kiralanan bir hizmettir ve kayıt süresi sonunda yenileme işlemi yapıldığı
                            sürece domain sahipliği korunur.
                        </div>
                    </div>

                    <div class="questions-box">
                        <div id="headingtwo">
                            <button class="btn questions-title collapsed" type="button" data-toggle="collapse"
                                    data-target="#questiontwo" aria-expanded="true" aria-controls="questiontwo">
                                Alan adı tescili ücretli midir? Domain fiyatları neden farklılık gösterir?
                            </button>
                        </div>

                        <div id="questiontwo" class="collapse questions-reponse" aria-labelledby="headingtwo"
                             data-parent="#frequently-questions">
                            Alan adı tescili için belirlenmiş bir ücret ödemek gereklidir. Domain fiyatları,
                            uzantılarına göre farklılıklar gösterebilir. Sahip olmak istediğiniz alan adını, minimum 1
                            yıldan maksimum 10 yıla kadar belirlenmiş olan kayıt ücretini ödenerek tecil edebilirsiniz.
                        </div>
                    </div>

                    <div class="questions-box">
                        <div id="headingtree">
                            <button class="btn questions-title collapsed" type="button" data-toggle="collapse"
                                    data-target="#questiontree" aria-expanded="true" aria-controls="questiontree">
                                Satın almak istediğim domain kayıtlı ise ne yapabilirim?
                            </button>
                        </div>

                        <div id="questiontree" class="collapse questions-reponse" aria-labelledby="headingtree"
                             data-parent="#frequently-questions">
                            Satın almak istediğiniz domain daha önce başkası tarafından kayıt edilmişse bu durumda
                            benzer anlam ifade eden alternatif kelimeleri sorgulayabilir veya yeni domain uzantılarını
                            değerlendirebilirsiniz. Yılda 0,99$’dan başlayan kayıt ücretleri ile yeni domain
                            uzantılarını tercih ederek jenerik ve akılda kalıcı bir domain sahibi olabilirsiniz.
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </div>
</section>


<?php
include 'footer.php';
?>

<!-- jquery -->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<!-- bootstrap JavaScript -->
<script src="js/bootstrap.min.js"></script>
<!-- template JavaScript -->
<script src="js/template-scripts.js"></script>
<!-- flickity JavaScript -->
<script src="js/flickity.pkgd.min.js"></script>
<!-- carousel JavaScript -->
<script src="owlcarousel/owl.carousel.min.js"></script>
<!-- parallax JavaScript -->
<script src="js/parallax.min.js"></script>
<!-- mailchamp JavaScript -->
<script src="js/mailchamp.js"></script>
<!-- bootstrap offcanvas -->
<script src="js/bootstrap.offcanvas.min.js"></script>
<!-- touchSwipe JavaScript -->
<script src="js/jquery.touchSwipe.min.js"></script>

<!-- seconde style additionel JavaScript -->
<script src="js/particles-code.js"></script>
<script src="js/particles.js"></script>
<script src="js/smoothscroll.js"></script>

</body>

</html>