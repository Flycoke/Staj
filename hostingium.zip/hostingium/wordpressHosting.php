<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Bredh flat responsive HTML & WHMCS hosting and domains template">
    <meta name="author" content="coodiv.net (nedjai mohamed)">
    <link rel="icon" href="favicon.ico">
    <title>bredh | servers</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- main css file -->
    <link href="css/main.min.css" rel="stylesheet">
    <!-- main css file -->
    <link href="css/style.css" rel="stylesheet">

</head>

<body>
<!-- start body -->

<div class="preloader">
    <!-- start preloader -->
    <div class="preloader-container">
        <svg version="1.1" id="L5" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px"
             y="0px" viewBox="0 0 100 100" enable-background="new 0 0 0 0" xml:space="preserve">
                <circle fill="#675cda" stroke="none" cx="6" cy="50" r="6">
                    <animateTransform attributeName="transform" dur="1s" type="translate" values="0 15 ; 0 -15; 0 15"
                                      repeatCount="indefinite" begin="0.1"/>
                </circle>
            <circle fill="#675cda" stroke="none" cx="30" cy="50" r="6">
                <animateTransform attributeName="transform" dur="1s" type="translate" values="0 10 ; 0 -10; 0 10"
                                  repeatCount="indefinite" begin="0.2"/>
            </circle>
            <circle fill="#675cda" stroke="none" cx="54" cy="50" r="6">
                <animateTransform attributeName="transform" dur="1s" type="translate" values="0 5 ; 0 -5; 0 5"
                                  repeatCount="indefinite" begin="0.3"/>
            </circle>
            </svg>
        <span>loading</span>
    </div>
</div>
<!-- end preloader -->

<div id="coodiv-header" class="d-flex mx-auto flex-column subpages-header moon-edition">
    <div class="bg_overlay_header">
        <div class="video-bg-nuhost-header">
            <div id="video_cover"></div>
            <video autoplay muted loop>
                <source src="media/coodiv-vid.mp4" type="video/mp4">
            </video>
            <span class="video-bg-nuhost-header-bg"></span>
        </div>

        <div id="particles-bg"></div>
        <div class="bg-img-header-new-moon">&nbsp;</div>
        <span class="header-shapes shape-01"></span>
        <span class="header-shapes shape-02"></span>
        <span class="header-shapes shape-03"></span>
    </div>
    <!-- Fixed navbar -->
    <?php
    include 'navbar.php';
    ?>
    <div class="mt-auto header-top-height"></div>
    <main class="container mb-auto">
        <div class="row">
            <div class="col-md-5 d-flex mx-auto flex-column">
                <div class="mb-auto"></div>
                <h3 class="mt-3 main-header-text-title">Wordpress Hosting
                    <span> <br>Otomatik Güncelleme ve Yedekleme</span>
                    <span> Test Ortamı (Staging) Altyapısı</span>
                    <span> Zararlı Dosya Taraması ve Koruma</span>
                </h3>
            </div>
            <div class="col-md-7">
                <div class="breadcrumb-hosting-pages row">
                    <a class="col-md-2" href="webHosting.php">
                        <img src="img/svgs/hosting.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">web hosting</span>
                    </a>

                    <a class="col-md-4 active" href="wordpressHosting.php">
                        <img src="img/svgs/servers.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">Wordpress Hosting</span>
                    </a>

                    <a class="col-md-2" href="eCommerceHosting.php">
                        <img src="img/svgs/clouds.svg" alt="#"/>
                        <span class="sub-breadcrumb-host-title">E-Ticaret Hosting</span>
                    </a>

                    <a class="col-md-2" href="mailHosting.php">
                        <img src="img/svgs/dedicated.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">Mail Hosting</span>
                    </a>
                    <a class="col-md-2" href="dedicatedHosting.php">
                        <img src="img/svgs/dedicated.svg" alt=""/>
                        <span class="sub-breadcrumb-host-title">Bayi Hosting</span>
                    </a>
                </div>
            </div>
        </div>
</main>
<div class="mt-auto"></div>
</div>

<section class="padding-100-0-0 position-relative">

    <div class="container-fluid">
        <div class="row justify-content-between">

            <div class="col-md-12 row justify-content-center">
                <div class="col-md-2">
                    <div class="third-pricing-table ">
                        <div class="plan-header">
                            <span class="headline">WP Başlangıç</span>

                            <span class="plan-price second-pricing-table-price monthly">
                                <i class="monthly">$78 <span>/mo</span></i>
                                </span>
                            <span class="activated-method">Activate in minutes</span>
                        </div>
                        <div class="package-body">
                            <ul>
                                <li><strong>1 Wordpress </strong>Web Sitesi</li>
                                <li><strong>10 GB</strong> Disk Alanı</li>
                                <li><strong>25.000</strong> Ziyaret</li>
                                <li><strong>Sınırsız</strong> E-Posta</li>
                                <li class="lineThrough"><strong>SSL</strong></li>
                                <li><strong>Ücretsiz</strong> Alan Adı</li>
                            </ul>
                        </div>
                        <div class="package-footer">
                            <a href="#">order now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="third-pricing-table ">
                        <div class="plan-header">
                            <span class="headline">WP Süper Başlangıç</span>

                            <span class="plan-price second-pricing-table-price monthly">
                                <i class="monthly">$78 <span>/mo</span></i>
                                </span>
                            <span class="activated-method">Activate in minutes</span>
                        </div>
                        <div class="package-body">
                            <ul>
                                <li><strong>1 Wordpress </strong>Web Sitesi</li>
                                <li><strong>30 GB</strong> Disk Alanı</li>
                                <li><strong>100.000</strong> Ziyaret</li>
                                <li><strong>Sınırsız</strong> E-Posta</li>
                                <li class="lineThrough"><strong>SSL</strong></li>
                                <li><strong>Ücretsiz</strong> Alan Adı</li>
                            </ul>
                        </div>
                        <div class="package-footer">
                            <a href="#">order now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="third-pricing-table side-right">
                        <div class="plan-header">
                            <span class="headline">WP Kurumsal</span>

                            <span class="plan-price second-pricing-table-price monthly">
                                <i class="monthly">$78 <span>/mo</span></i>
                                </span>
                            <span class="activated-method">Activate in minutes</span>
                        </div>
                        <div class="package-body">
                            <ul>
                                <li><strong>1 Wordpress </strong>Web Sitesi</li>
                                <li><strong>Sınırsız SSD</strong> Disk Alanı</li>
                                <li><strong>Sınırsız</strong> Ziyaret</li>
                                <li><strong>Sınırsız</strong> E-Posta</li>
                                <li><strong>Ömür Boyu Ücretsiz</strong> SSL</li>
                                <li><strong>Ücretsiz</strong> Alan Adı</li>
                            </ul>
                        </div>
                        <div class="package-footer">
                            <a href="#">order now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="third-pricing-table ">
                        <div class="plan-header">
                            <span class="headline">WP Profesyonel</span>

                            <span class="plan-price second-pricing-table-price monthly">
                                <i class="monthly">$78 <span>/mo</span></i>
                                </span>
                            <span class="activated-method">Activate in minutes</span>
                        </div>
                        <div class="package-body">
                            <ul>
                                <li><strong>5 Wordpress </strong>Web Sitesi</li>
                                <li><strong>Sınırsız SSD</strong> Disk Alanı</li>
                                <li><strong>Sınırsız</strong> Ziyaret</li>
                                <li><strong>Sınırsız</strong> E-Posta</li>
                                <li><strong>Ömür Boyu Ücretsiz</strong> SSL</li>
                                <li><strong>Ücretsiz</strong> Alan Adı</li>
                            </ul>
                        </div>
                        <div class="package-footer">
                            <a href="#">order now</a>
                        </div>
                    </div>
                </div>


            </div>


        </div>
    </div>
</section>


<section class="padding-100-0 with-top-border">
    <div class="container">
        <h5 class="title-default-coodiv-two">Sıkça Sorulan Sorular</h5>

        <div class="row justify-content-center mr-tp-40">
            <div class="col-md-9">

                <div class="accordion" id="frequently-questions">

                    <div class="questions-box">
                        <div id="headingOne">
                            <button class="btn questions-title" type="button" data-toggle="collapse"
                                    data-target="#questionone" aria-expanded="true" aria-controls="questionone">
                                Wordpress nedir ?
                            </button>
                        </div>

                        <div id="questionone" class="collapse show questions-reponse" aria-labelledby="headingOne"
                             data-parent="#frequently-questions">
                            Dünya’nın en çok kullanılan açık kaynak içerik yönetim sistemi olan WordPress ile kodlama
                            bilmeden web sitenizi yayınlayabilir, kolayca tema ve eklenti yükleyebilir, içeriklerinizi
                            hemen yayınlamaya başlayabilirsiniz.
                        </div>
                    </div>

                    <div class="questions-box">
                        <div id="headingtwo">
                            <button class="btn questions-title collapsed" type="button" data-toggle="collapse"
                                    data-target="#questiontwo" aria-expanded="true" aria-controls="questiontwo">
                                Wordpress Hosting nedir ?
                            </button>
                        </div>

                        <div id="questiontwo" class="collapse questions-reponse" aria-labelledby="headingtwo"
                             data-parent="#frequently-questions">
                            Hostingium WordPress Hosting paketleri ile kimseye ihtiyaç duymadan kolayca web sitenizi
                            yayınlayabilir, tek noktadan yönetebilirsiniz. WordPress web siteleri için özel olarak
                            kurgulanmış ve optimize edilmiş yüksek performanslı sunucularda siteniz, yüksek hızda ve
                            güvenle çalışır.
                        </div>
                    </div>


                </div>

            </div>
        </div>

    </div>
</section>

<?php
include 'footer.php';
?>


<!-- jquery -->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<!-- bootstrap JavaScript -->
<script src="js/bootstrap.min.js"></script>
<!-- template JavaScript -->
<script src="js/template-scripts.js"></script>
<!-- flickity JavaScript -->
<script src="js/flickity.pkgd.min.js"></script>
<!-- carousel JavaScript -->
<script src="owlcarousel/owl.carousel.min.js"></script>
<!-- parallax JavaScript -->
<script src="js/parallax.min.js"></script>
<!-- mailchamp JavaScript -->
<script src="js/mailchamp.js"></script>
<!-- bootstrap offcanvas -->
<script src="js/bootstrap.offcanvas.min.js"></script>
<!-- touchSwipe JavaScript -->
<script src="js/jquery.touchSwipe.min.js"></script>

<!-- seconde style additionel JavaScript -->
<script src="js/particles-code.js"></script>
<script src="js/particles.js"></script>
<script src="js/smoothscroll.js"></script>
</body>

</html>