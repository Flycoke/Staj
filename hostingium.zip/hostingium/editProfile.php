<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Bredh flat responsive HTML & WHMCS hosting and domains template">
    <meta name="author" content="coodiv.net (nedjai mohamed)">
    <link rel="icon" href="favicon.ico">
    <title>bredh | help center</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- main css file -->
    <link href="css/main.min.css" rel="stylesheet">
    <!-- main css file -->
    <link href="css/style.css" rel="stylesheet">

</head>

<body>
    <!-- start body -->


    <div class="preloader">
        <!-- start preloader -->
        <div class="preloader-container">
            <svg version="1.1" id="L5" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 0 0" xml:space="preserve">
                <circle fill="#675cda" stroke="none" cx="6" cy="50" r="6">
                    <animateTransform attributeName="transform" dur="1s" type="translate" values="0 15 ; 0 -15; 0 15" repeatCount="indefinite" begin="0.1" />
                </circle>
                <circle fill="#675cda" stroke="none" cx="30" cy="50" r="6">
                    <animateTransform attributeName="transform" dur="1s" type="translate" values="0 10 ; 0 -10; 0 10" repeatCount="indefinite" begin="0.2" />
                </circle>
                <circle fill="#675cda" stroke="none" cx="54" cy="50" r="6">
                    <animateTransform attributeName="transform" dur="1s" type="translate" values="0 5 ; 0 -5; 0 5" repeatCount="indefinite" begin="0.3" />
                </circle>
            </svg>
            <span>loading</span>
        </div>
    </div>
    <!-- end preloader -->

    <div id="coodiv-header" class="subpages-header-min moon-edition">
        <div class="bg_overlay_header">
            <div class="video-bg-nuhost-header">
                <div id="video_cover"></div>
                <video autoplay muted loop>
                    <source src="media/coodiv-vid.mp4" type="video/mp4">
                </video>
                <span class="video-bg-nuhost-header-bg"></span>
            </div>

            <div id="particles-bg"></div>
            <div class="bg-img-header-new-moon">&nbsp;</div>
            <span class="header-shapes shape-01"></span>
            <span class="header-shapes shape-02"></span>
            <span class="header-shapes shape-03"></span>
        </div>ed navbar -->
        <?php
        include 'navbar.php';
        ?>
    </div>
<section>
    <div class="container">
        <div class="main">
            <div class="row">
                <div class="col-md-4 mt-1">
                    <div class="card text-center sidebar">
                        <div class="card-body">
                            <img src="img/profile.jpg" alt="" class="rounded-circle" width="150">
                            <div class="mt-3">
                                <h3 clas>Ahmet Emin KOÇAL</h3>
                                <hr>
                                <a href="editProfile.php">Ana Sayfa</a>
                                <a href="contact.php">Destek</a>
                                <a href="profileSettings.php">Ayarlar</a>
                                <a href="">Çıkış Yapın</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 mt-1">
                    <div class="card mb-3 content">
                        <h1 class="m-3 pt-3">Hakkında</h1>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <h5>Tam Adınız</h5>
                                </div>
                                <div class="col-md-9 text-secondary name">
                                    Ahmet Emin KOÇAL
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-3">
                                    <h5>E-Posta</h5>
                                </div>
                                <div class="col-md-9 text-secondary">
                                    info@exorditech.com
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-3">
                                    <h5>Telefon</h5>
                                </div>
                                <div class="col-md-9 text-secondary">
                                    +90 850 346 5589
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-3">
                                    <h5>Adres</h5>
                                </div>
                                <div class="col-md-9 text-secondary">
                                    Orta, Kavaklar Cd. No:15, 54100 Adapazarı/Sakarya
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card mb-3 content">
                        <h1 class="m-3">Son Alımlarınız</h1>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <h5>Ürün</h5>
                                </div>
                                <div class="col-md-9 text-secondary">
                                    Ürün Detayları
                                </div>
                            </div>
                            <hr>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


    <?php
    include 'footer.php';
    ?>

    <!-- jquery -->
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <!-- bootstrap JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <!-- template JavaScript -->
    <script src="js/template-scripts.js"></script>
    <!-- flickity JavaScript -->
    <script src="js/flickity.pkgd.min.js"></script>
    <!-- carousel JavaScript -->
    <script src="owlcarousel/owl.carousel.min.js"></script>
    <!-- parallax JavaScript -->
    <script src="js/parallax.min.js"></script>
    <!-- mailchamp JavaScript -->
    <script src="js/mailchamp.js"></script>
    <!-- bootstrap offcanvas -->
    <script src="js/bootstrap.offcanvas.min.js"></script>
    <!-- touchSwipe JavaScript -->
    <script src="js/jquery.touchSwipe.min.js"></script>
	
    <!-- seconde style additionel JavaScript -->
	<script src="js/particles-code.js"></script>
	<script src="js/particles.js"></script>
	<script src="js/smoothscroll.js"></script>
</body>

</html>