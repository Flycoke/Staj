<html>
<body>

<nav id="coodiv-navbar-header" class="navbar navbar-expand-md fixed-header-layout">
    <div class="container main-header-coodiv-s">
        <a class="navbar-brand" href="index.php">
            <img class="w-logo" src="img/header/logo-w.png" alt=""/>
            <img class="b-logo" src="img/header/logo.png" alt=""/>
        </a>
        <button class="navbar-toggle offcanvas-toggle menu-btn-span-bar ml-auto" data-toggle="offcanvas"
                data-target="#offcanvas-menu-home">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <div class="collapse navbar-collapse navbar-offcanvas" id="offcanvas-menu-home">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php" role="button" aria-haspopup="true" aria-expanded="false">ANASAYFA</a>
                </li>
                <li>
                    <a class="nav-link" href="webHosting.php" role="button" aria-haspopup="true" aria-expanded="false">HOSTİNG</a>
                </li>
                <li>
                    <a class="nav-link" href="ssl.php" role="button" aria-haspopup="true" aria-expanded="false">SSL SERTİFİKASI</a>
                </li>
                <li>
                    <a class="nav-link" href="cloudServer.php" role="button" aria-haspopup="true" aria-expanded="false">SUNUCU</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="contact.php">BİZE ULAŞIN</a>
                </li>
            </ul>
        </div>
        <ul class="header-user-info-coodiv">
            <li class="dropdown"><a role="button" id="header-login-dropdown" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false" href="#">ÜYE GİRİŞİ</a>
                <!-- user header dropdown -->
                <div class="dropdown-menu coodiv-dropdown-header user-login-dropdown"
                     aria-labelledby="header-login-dropdown">
                    <form class="user-login-dropdown-form" action="signin.php" data-form="validate">
                        <div class="form-group username">
                            <input type="email" name="username" placeholder="Your Email" class="form-control">
                            <i class="fas fa-at"></i>
                        </div>

                        <div class="form-group password">
                            <input type="password" name="password" placeholder="Password" class="form-control">
                            <i class="fas fa-lock"></i>
                        </div>

                        <button data-toggle="tooltip" data-placement="left" title="login"
                                class="user-login-dropdown-form-button" type="submit"><i
                                class="fas fa-angle-right"></i></button>

                    </form>
                </div>
                <!-- end user header dropdown -->
            </li>
        </ul>
    </div>
</nav>
</body>
</html>