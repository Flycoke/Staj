<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Bredh flat responsive HTML & WHMCS hosting and domains template">
    <meta name="author" content="coodiv.net (nedjai mohamed)">
    <link rel="icon" href="favicon.ico">
    <title>Hostingium | ANASAYFA</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- main css file -->
    <link href="css/main.min.css" rel="stylesheet">
    <!-- Alptekin's CSS -->
    <link href="css/style.css" rel="stylesheet">

</head>

<body><!-- start body -->

<div class="preloader"><!-- start preloader -->
    <div class="preloader-container">
        <svg version="1.1" id="L5" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px"
             y="0px" viewBox="0 0 100 100" enable-background="new 0 0 0 0" xml:space="preserve">
                <circle fill="#675cda" stroke="none" cx="6" cy="50" r="6">
                    <animateTransform attributeName="transform" dur="1s" type="translate" values="0 15 ; 0 -15; 0 15"
                                      repeatCount="indefinite" begin="0.1"/>
                </circle>
            <circle fill="#675cda" stroke="none" cx="30" cy="50" r="6">
                <animateTransform attributeName="transform" dur="1s" type="translate" values="0 10 ; 0 -10; 0 10"
                                  repeatCount="indefinite" begin="0.2"/>
            </circle>
            <circle fill="#675cda" stroke="none" cx="54" cy="50" r="6">
                <animateTransform attributeName="transform" dur="1s" type="translate" values="0 5 ; 0 -5; 0 5"
                                  repeatCount="indefinite" begin="0.3"/>
            </circle>
            </svg>
        <span>loading</span>
    </div>
</div><!-- end preloader -->

<div id="coodiv-header" class="d-flex mx-auto flex-column moon-edition"><!-- start header -->
    <div class="bg_overlay_header">
        <div class="video-bg-nuhost-header">
            <div id="video_cover"></div>
            <video autoplay muted loop>
                <source src="media/coodiv-vid.mp4" type="video/mp4">
            </video>
            <span class="video-bg-nuhost-header-bg"></span>
        </div>

        <div id="particles-bg"></div>
        <div class="bg-img-header-new-moon">&nbsp;</div>
        <span class="header-shapes shape-01"></span>
        <span class="header-shapes shape-02"></span>
        <span class="header-shapes shape-03"></span>
    </div>
    <!-- Fixed navbar -->
    <?php
    include 'navbar.php';
    ?>
    <div class="mt-auto header-top-height"></div>
    <main class="container mb-auto">
        <div class="carousel carousel-main">
            <div class="carousel-cell">
                <h3 class="mt-3 main-header-text-title"><span>En İyi Hosting Hizmeti Burada</span>GÜVENLİ VE GARANTİLİ
                </h3>
                <div class="row justify-content-center domain-search-row">
                    <form action="domainQuery.php" id="domain-search-header" class="col-md-7">
                        <i class="fas fa-globe"></i>
                        <input type="text" placeholder="alan adı ara" id="domain" name="domains">
                        <span class="inline-button-domain-order">
                  	  <button data-toggle="tooltip" data-placement="left" title="transfer" id="transfer-btn"
                              type="submit" name="transfer" value="Transfer"><i class="fas fa-undo"></i></button>
                  	  <button data-toggle="tooltip" data-placement="left" title="search" id="search-btn" type="submit"
                              name="submit" value="Search"><i class="fas fa-search"></i></button>
                  	  </span>
                        <div class="domain-price-header mr-auto">
                            <a>
                                <img src="img/domain/com.png" alt="domain"><!-- domain name -->
                                <span>$14.99</span><!-- domain price -->
                            </a>

                            <a>
                                <img src="img/domain/net.png" alt="domain"><!-- domain name -->
                                <span>$9.99</span><!-- domain price -->
                            </a>

                            <a>
                                <img src="img/domain/org.png" alt="domain"><!-- domain name -->
                                <span>$0.99</span><!-- domain price -->
                            </a>

                            <a class="no-phon-dsply">
                                <img src="img/domain/store.png" alt="domain"><!-- domain name -->
                                <span>$8.99</span><!-- domain price -->
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>
    <div class="mt-auto"></div>
</div><!-- end header -->

<section class="padding-40-0-100 position-relative">
    <div class="container">
        <h5 class="title-default-coodiv-two">Harika Planlara Göz Atın ve Şimdi Sipariş Edin <span class="mr-tp-20">sizin için en iyi paketi seçin.</span>
        </h5>

        <div class="row justify-content-start second-pricing-table-container mr-tp-30">
            <div class="col-md-4">
                <div class="second-pricing-table style-2 active">
                    <h5 class="second-pricing-table-title">Başlangıç Planı <span>En ekonomik fiyata web siteniz için güçlü bir başlangıç yapın.</span></h5>
                    <span class="second-pricing-table-price monthly">
	                    <i class="monthly">10$<small>/ay</small></i>
	                    </span>

                    <ul class="second-pricing-table-body">
                        <li><strong>1 Adet</strong> Web Sitesi</li>
                        <li><strong>10 GB</strong> SSD Disk Alanı</li>
                        <li><strong>500 GB</strong> Trafik</li>
                    </ul>
                    <a class="second-pricing-table-button" href="#">Satın Al</a>
                </div>
            </div>

            <div class="col-md-4">
                <div class="second-pricing-table style-2 active">
                    <h5 class="second-pricing-table-title">Hazır Web Sitesi Aracı <span><strong>GiumSite</strong> ile dakikalar içerisinde hazır web sitesi sahibi olun</span></h5>
                    <span class="second-pricing-table-price monthly">
	                    <i class="monthly">20$<small>/ay</small></i></span>
                    <ul class="second-pricing-table-body">
                        <li><strong>Ücretsiz</strong> Alan Adı</li>
                        <li><strong>Akıllı Site</strong> Sihirbazı</li>
                        <li><strong>Sektörel</strong> Hazır Temalar</li>
                    </ul>
                    <a class="second-pricing-table-button" href="#">Satın Al</a>
                </div>
            </div>

            <div class="col-md-4">
                <div class="second-pricing-table style-2 active">
                    <h5 class="second-pricing-table-title">Wordpress Hosting<span>Sadece WordPress için tasarlanmış Jet Hızında Web Siteleri Kurun</span></h5>
                    <span class="second-pricing-table-price monthly">
	                    <i class="monthly">10$<small>/ay</small></i></span>

                    <ul class="second-pricing-table-body">
                        <li><strong>30 GB SSD</strong> Disk Alanı</li>
                        <li><strong>Otomatik</strong> Kurulum</li>
                        <li><strong>Ücretsiz</strong> Günlük Yedek</li>
                    </ul>
                    <a class="second-pricing-table-button" href="#">Satın Al</a>
                </div>
            </div>

        </div><!-- end row -->
    </div><!-- end container -->
</section>

<section class="padding-40-0-100 position-relative bgServer ">
    <div class="container ">

        <div class="row justify-content-center second-pricing-table-container mr-tp-30">
            <div class="col-md-4">
                <div class="second-pricing-table style-2 active">
                    <h5 class="second-pricing-table-title">Bulut(Cloud) Sunucu <span>En hesaplı yeni nesil sanal sunucular</span></h5>
                    <span class="second-pricing-table-price monthly">
	                    <i class="monthly">10$<small>/ay <br> başlayan fiyatlarla</small></i>
	                    </span>
                    <a class="second-pricing-table-button" href="#">Satın Al</a>
                </div>
            </div>

            <div class="col-md-4">
                <div class="second-pricing-table style-2 active">
                    <h5 class="second-pricing-table-title">Dedicated (Fiziksel) Sunucu <span>Tamamen size ait altyapı</span></h5>
                    <span class="second-pricing-table-price monthly">
	                    <i class="monthly">20$<small>/ay<br> başlayan fiyatlarla</small></i></span>
                    <a class="second-pricing-table-button" href="#">Satın Al</a>
                </div>
            </div>



        </div><!-- end row -->
    </div><!-- end container -->
</section>



<?php
include 'footer.php';
?>

<!-- jquery -->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<!-- bootstrap JavaScript -->
<script src="js/bootstrap.min.js"></script>
<!-- template JavaScript -->
<script src="js/template-scripts.js"></script>
<!-- flickity JavaScript -->
<script src="js/flickity.pkgd.min.js"></script>
<!-- carousel JavaScript -->
<script src="owlcarousel/owl.carousel.min.js"></script>
<!-- parallax JavaScript -->
<script src="js/parallax.min.js"></script>
<!-- mailchamp JavaScript -->
<script src="js/mailchamp.js"></script>
<!-- bootstrap offcanvas -->
<script src="js/bootstrap.offcanvas.min.js"></script>
<!-- touchSwipe JavaScript -->
<script src="js/jquery.touchSwipe.min.js"></script>
<!-- seconde style additionel JavaScript -->
<script src="js/particles-code.js"></script>
<script src="js/particles.js"></script>
<script src="js/smoothscroll.js"></script>
<!-- video background JavaScript -->
<script src="js/video-bg.js"></script>
</body>

</html>